//! Prototype of the document assembly contract.
//!
//! A rendered clinical document contains exactly three kinds of text:
//!   1. template prose     — versioned, reviewed boilerplate; never a clinical assertion
//!   2. document claims    — a statement backed by a source document, page, and date
//!   3. annotation claims  — a surgeon's attributed opinion, never rendered as chart fact
//!
//! Clinical text reaches a template only through `claim(ordinal)`. The engine records
//! every ordinal rendered, so "unsupported claim" is impossible by construction and
//! "criterion coverage" is a set difference. The engine has no clock, no I/O and no
//! storage: the same inputs always produce the same bytes and the same hash.

use minijinja::{Environment, Error, ErrorKind, UndefinedBehavior, Value, context};
use serde::Serialize;
use sha2::{Digest, Sha256};
use std::collections::{BTreeMap, BTreeSet};
use std::sync::{Arc, Mutex};

/// Mirror of ADR-003. Read-only here: the engine never assigns an evidence state.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "lowercase")]
pub enum EvidenceState { Met, Gap, Void }

#[derive(Debug, Clone, Serialize)]
#[serde(tag = "kind", rename_all = "snake_case")]
pub enum Provenance {
    /// Mirrors `letter_claims.document_id` + `page_number`, plus the provenance
    /// the signing precondition requires (effective date, content hash).
    Document { document_id: String, title: String, page: u32, effective_date: String, content_sha256: String },
    /// Mirrors `letter_claims.annotation_id`. Rendered with attribution, never as chart fact.
    Annotation { annotation_id: String, author: String, authored_on: String },
}

#[derive(Debug, Clone, Serialize)]
pub struct Claim { pub ordinal: u32, pub text: String, pub provenance: Provenance }

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize)]
#[serde(rename_all = "snake_case")]
pub enum QaOutcome { Pass, Fail, NotApplicable }

/// Shaped to become a `letter_qa_results` row; the host persists it.
#[derive(Debug, Clone, Serialize)]
pub struct QaFinding { pub check_key: &'static str, pub outcome: QaOutcome, pub detail: String }

#[derive(Debug, Serialize)]
pub struct Assembly {
    pub canonical_markdown: String,
    /// Ordinals in first-render order; the host writes one `letter_claims` row per entry.
    pub rendered_claims: Vec<u32>,
    pub qa: Vec<QaFinding>,
    /// sha256 over kind key, kind version, template digest and canonical bytes.
    pub content_sha256: String,
}

pub struct AssemblyInput<'a> {
    pub kind_key: &'a str,
    pub kind_version: u32,
    pub templates: &'a BTreeMap<String, String>,
    pub root: &'a str,
    pub claims: &'a [Claim],
    /// Ordinals the governing policy section requires (Criterion Coverage).
    pub required_ordinals: &'a BTreeSet<u32>,
    /// Non-clinical context: letterhead, dates, routing. Clinical facts are refused here.
    pub context: serde_json::Value,
}

fn cite(p: &Provenance) -> String {
    match p {
        Provenance::Document { title, page, effective_date, .. } => format!("({title}, p. {page}, {effective_date})"),
        Provenance::Annotation { author, authored_on, .. } => format!("(clinical judgment of {author}, {authored_on})"),
    }
}

fn render_claim(c: &Claim) -> String {
    match &c.provenance {
        Provenance::Document { .. } => format!("{} {}", c.text, cite(&c.provenance)),
        // Attribution is part of the sentence, so it survives copy, fax and OCR.
        Provenance::Annotation { author, .. } => format!("In the clinical judgment of {author}, {} {}", c.text, cite(&c.provenance)),
    }
}

pub fn assemble(input: &AssemblyInput) -> Result<Assembly, Error> {
    let by_ordinal: Arc<BTreeMap<u32, Claim>> =
        Arc::new(input.claims.iter().map(|c| (c.ordinal, c.clone())).collect());
    let used: Arc<Mutex<Vec<u32>>> = Arc::new(Mutex::new(Vec::new()));

    let mut env = Environment::new();
    env.set_undefined_behavior(UndefinedBehavior::SemiStrict);
    env.set_trim_blocks(true);
    env.set_lstrip_blocks(true);
    let templates = input.templates.clone();
    env.set_loader(move |name| Ok(templates.get(name).cloned()));

    let (claims_fn, used_fn) = (Arc::clone(&by_ordinal), Arc::clone(&used));
    env.add_function("claim", move |ordinal: u32| -> Result<Value, Error> {
        let c = claims_fn.get(&ordinal).ok_or_else(|| {
            Error::new(ErrorKind::InvalidOperation, format!("claim {ordinal} does not exist; clinical text must come from a claim"))
        })?;
        let mut u = used_fn.lock().expect("claim usage lock");
        if !u.contains(&ordinal) { u.push(ordinal); }
        Ok(Value::from(render_claim(c)))
    });

    let body = env.get_template(input.root)?.render(context! { ctx => input.context })?;
    let rendered_claims = used.lock().expect("claim usage lock").clone();

    let rendered: BTreeSet<u32> = rendered_claims.iter().copied().collect();
    let uncovered: Vec<u32> = input.required_ordinals.difference(&rendered).copied().collect();
    let qa = vec![
        QaFinding { check_key: "unsupported_claim", outcome: QaOutcome::Pass,
                    detail: "Clinical text entered only through claim(); every rendered claim carries provenance.".into() },
        QaFinding { check_key: "criterion_coverage",
                    outcome: if uncovered.is_empty() { QaOutcome::Pass } else { QaOutcome::Fail },
                    detail: if uncovered.is_empty() { "All required claims rendered.".into() } else { format!("Required claims not rendered: {uncovered:?}") } },
    ];

    let mut digest_input = String::new();
    for (name, src) in input.templates { digest_input.push_str(name); digest_input.push('\0'); digest_input.push_str(src); digest_input.push('\0'); }
    let template_digest = hex(&Sha256::digest(digest_input.as_bytes()));
    let mut h = Sha256::new();
    h.update(format!("{}\0{}\0{}\0", input.kind_key, input.kind_version, template_digest).as_bytes());
    h.update(body.as_bytes());

    Ok(Assembly { canonical_markdown: body, rendered_claims, qa, content_sha256: hex(&h.finalize()) })
}

fn hex(bytes: &[u8]) -> String { bytes.iter().map(|b| format!("{b:02x}")).collect() }

#[cfg(test)]
mod tests {
    use super::*;

    fn fixture() -> (BTreeMap<String, String>, Vec<Claim>) {
        let mut t = BTreeMap::new();
        t.insert("letter.md.j2".into(), "Dear {{ ctx.salutation }},\n\n{{ claim(1) }}\n\n{{ claim(2) }}\n".into());
        let claims = vec![
            Claim { ordinal: 1, text: "Flexion-extension radiographs demonstrate 4.5 mm of translation at L4-L5.".into(),
                    provenance: Provenance::Document { document_id: "doc-rad-1".into(), title: "Flexion-extension radiograph report".into(),
                        page: 1, effective_date: "2026-04-15".into(), content_sha256: "ab12".into() } },
            Claim { ordinal: 2, text: "decompression alone would destabilize the segment.".into(),
                    provenance: Provenance::Annotation { annotation_id: "ann-7".into(), author: "Dr. A. Okafor".into(), authored_on: "2026-09-01".into() } },
            Claim { ordinal: 3, text: "Nicotine abstinence is verified by cotinine testing.".into(),
                    provenance: Provenance::Document { document_id: "doc-lab-2".into(), title: "Laboratory results".into(),
                        page: 1, effective_date: "2026-08-20".into(), content_sha256: "cd34".into() } },
        ];
        (t, claims)
    }

    fn input<'a>(t: &'a BTreeMap<String, String>, c: &'a [Claim], req: &'a BTreeSet<u32>) -> AssemblyInput<'a> {
        AssemblyInput { kind_key: "pa.initial_request", kind_version: 1, templates: t, root: "letter.md.j2",
                        claims: c, required_ordinals: req, context: serde_json::json!({ "salutation": "Reviewer" }) }
    }

    #[test]
    fn document_claims_render_with_page_and_date_and_annotations_with_attribution() {
        let (t, c) = fixture(); let req = BTreeSet::from([1, 2]);
        let a = assemble(&input(&t, &c, &req)).unwrap();
        assert!(a.canonical_markdown.contains("(Flexion-extension radiograph report, p. 1, 2026-04-15)"));
        assert!(a.canonical_markdown.contains("In the clinical judgment of Dr. A. Okafor,"));
        assert_eq!(a.rendered_claims, vec![1, 2]);
        assert!(a.qa.iter().all(|q| q.outcome == QaOutcome::Pass));
    }

    #[test]
    fn required_claim_left_out_fails_criterion_coverage() {
        let (t, c) = fixture(); let req = BTreeSet::from([1, 2, 3]);
        let a = assemble(&input(&t, &c, &req)).unwrap();
        let cov = a.qa.iter().find(|q| q.check_key == "criterion_coverage").unwrap();
        assert_eq!(cov.outcome, QaOutcome::Fail);
        assert!(cov.detail.contains("[3]"));
    }

    #[test]
    fn a_template_cannot_invent_a_claim() {
        let (mut t, c) = fixture(); let req = BTreeSet::new();
        t.insert("letter.md.j2".into(), "{{ claim(99) }}".into());
        let err = assemble(&input(&t, &c, &req)).unwrap_err().to_string();
        assert!(err.contains("claim 99 does not exist"), "{err}");
    }

    #[test]
    fn same_inputs_same_hash_and_template_edits_change_it() {
        let (t, c) = fixture(); let req = BTreeSet::from([1, 2]);
        let h1 = assemble(&input(&t, &c, &req)).unwrap().content_sha256;
        let h2 = assemble(&input(&t, &c, &req)).unwrap().content_sha256;
        assert_eq!(h1, h2);
        let mut t2 = t.clone();
        t2.insert("unused_partial.md.j2".into(), "changed boilerplate".into());
        let h3 = assemble(&input(&t2, &c, &req)).unwrap().content_sha256;
        assert_ne!(h1, h3, "a template package change must change the affirmed hash");
    }
}
