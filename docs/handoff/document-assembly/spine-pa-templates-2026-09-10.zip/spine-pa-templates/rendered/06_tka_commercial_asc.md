![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Lone Star Employer Health Plan — Appeals\
PO Box 0000, Example City, TX 75000\
Fax (800) 555-0188

**RE: Level 1 Internal Appeal of Adverse Benefit Determination**

| Field | Value |
|---|---|
| Member | Gloria J. Pennington |
| Date of birth | 1959-12-21 |
| Member ID | LSE771023488 |
| Group / plan | EMP-44120 / Choice PPO |
| Case number | LSE-26-5512093 |
| Determination date | 2026-09-03 |
| Requested service | Right total knee arthroplasty |
| Codes | 27447-RT |
| Diagnoses | M17.11 |
| Site of service | Ambulatory surgery center |
| Requesting physician | Erik Lindqvist, MD · NPI 1639000037 |
| Facility | Southlake Surgery Center · NPI 1851000051 |
| Anticipated date of service | 2026-10-08 |

Dear Appeals Reviewer,

I am submitting this appeal on behalf of my patient, Gloria J. Pennington, regarding the adverse benefit determination dated 2026-09-03 (reference LSE-26-5512093) denying right total knee arthroplasty. The requested service is medically necessary and meets each applicable criterion of Total Knee Arthroplasty Medical Policy (LSE-ORTHO-07), as detailed below. I respectfully request that the determination be reversed and the service authorized.

## 1. Determination Being Addressed

The adverse benefit determination dated 2026-09-03 cites 3 reasons. Each is quoted verbatim and answered in the Response to Denial Reasons section.

The determination does not identify the specific criteria relied upon. This response therefore addresses Total Knee Arthroplasty Medical Policy (LSE-ORTHO-07, sample, effective 2026-04-01), which governs the requested service.

## 2. Clinical Summary

Ms. Pennington is a 66-year-old woman with end-stage primary osteoarthritis of the right knee, first documented on 2024-04-10. She reports daily right knee pain, worse with stairs and after walking, with night pain that wakes her most nights.

**Functional impact.** She uses a cane, cannot manage stairs without a rail, and has stopped her weekly volunteer shifts.

| ICD-10-CM | Description |
|---|---|
| M17.11 | Unilateral primary osteoarthritis, right knee (primary) |

## 3. Total Joint Arthroplasty Evidence

### Joint Status (Knee, right)

| Finding | Value | Date | Source |
|---|---|---|---|
| Radiographic grade | Kellgren-Lawrence grade 4 | 2026-07-09 | Exhibit D |
| Radiographic findings | Bone-on-bone medial compartment, large osteophytes, subchondral sclerosis | 2026-07-09 | Exhibit D |
| Range of motion | 5° to 95° (flexion contracture of 5°) | 2026-07-09 | Exhibit B |
| Deformity / instability | 8° varus deformity, correctable to 4°; no ligamentous instability | 2026-07-09 | Exhibit B |

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| KOOS JR | 2026-07-09 | 38.5 (0–100; higher is better) | Severe knee-related disability | Exhibit B |

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2025-06-02 to 2025-08-22 | 16 sessions | No lasting improvement | Exhibit C |
| NSAIDs and topical diclofenac | 2024-04-15 to 2026-07-09 | Naproxen 500 mg twice daily; topical diclofenac | Partial relief; naproxen stopped for rising creatinine | Exhibit C |
| Intra-articular corticosteroid injections | 2025-02-11 to 2026-03-17 | Three injections | Relief shortened from 10 weeks to 2 weeks | Exhibit C |
| Weight management | 2025-01-06 to 2026-07-09 | Dietitian-supervised program | Lost 14 lb; pain unchanged | Exhibit C |
| Cane | 2025-09-01 to 2026-07-09 | Single-point cane | Improved stability; pain unchanged | Exhibit B |

Documented conservative care spans 116 weeks (2024-04-15 to 2026-07-09), meeting the policy minimum of 12 weeks, and includes physical therapy, medication management, injection therapy, weight management, and an assistive device. Symptoms persisted despite this treatment.

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| Nicotine | Never | 2026-07-09 | Nicotine-free ≥ 4 weeks | Exhibit B |
| BMI | 36.8 kg/m² | 2026-07-09 | ≤ 40 | Exhibit B |
| HbA1c | 7.1% | 2026-08-14 | ≤ 8.0% | Exhibit E |

### Site of Service

The procedure is planned in the ambulatory surgery center setting at Southlake Surgery Center. Her comorbidities are well controlled, she meets the facility's outpatient arthroplasty criteria, and her spouse will provide home support after same-day discharge.

## 4. Criterion-by-Criterion Response

Each criterion below is quoted from Total Knee Arthroplasty Medical Policy (LSE-ORTHO-07).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| 1 | Radiographic evidence of advanced osteoarthritis (Kellgren-Lawrence grade 3 or 4) | Met | KL grade 4, bone-on-bone medial compartment | Exhibit D |
| 2 | Functional limitation documented on a validated instrument | Met — documentation enclosed | KOOS JR 38.5 on 2026-07-09 | Exhibit B |
| 3 | At least 12 weeks of nonoperative care including physical therapy, medication, and injection | Met | PT, NSAIDs, three injections, weight management, cane | Exhibit C |
| 4 | BMI of 40 or less and HbA1c of 8.0% or less | Met | BMI 36.8; HbA1c 7.1% | Exhibit E |

Documentation for criterion 2 was not part of the original submission and is enclosed with this appeal.

## 5. Response to Denial Reasons

### Reason 1

> Radiographic evidence of advanced arthritis was not provided.

**Response.** This requirement was addressed in the original submission. The radiograph report included in the original request documents Kellgren-Lawrence grade 4 osteoarthritis with a bone-on-bone medial compartment.

**Where it is documented:** Weight-bearing right knee radiograph report (Exhibit D).

### Reason 2

> Functional limitation has not been documented using a validated instrument.

**Response.** Documentation addressing this requirement was not part of the original submission and is now enclosed. Her KOOS JR score of 38.5 on 2026-07-09 reflects severe knee-related disability. The scored instrument is now enclosed with the office note.

**Enclosed documentation:** Office note with scored KOOS JR (Exhibit B).

### Reason 3

> The member has not completed a trial of hyaluronic acid injections.

**Response.** This patient's clinical circumstances fall outside the assumptions underlying this requirement. Viscosupplementation is not a reasonable option in bone-on-bone, Kellgren-Lawrence grade 4 disease with a fixed flexion contracture, and corticosteroid injections have already lost effect.

**Risk of the policy-preferred course:** Delaying arthroplasty for an injection series risks progression of the flexion contracture and varus deformity, which worsens function and complicates the eventual reconstruction. (Exhibit D)

## 6. Medical Necessity

Total knee arthroplasty is indicated for end-stage osteoarthritis with severe functional limitation after failed nonoperative care. She meets each element, and her risk factors are optimized.

**Alternatives considered.** Injections have lost effect, and NSAIDs are contraindicated by declining renal function. Unicompartmental arthroplasty is not appropriate given the fixed flexion contracture and tricompartmental changes.

**Consequences of delay or denial.** Progressive deformity and contracture, falls risk, and loss of the risk-factor optimization she has achieved.

## 7. Procedural Requests

- Please provide copies of the specific criteria, guidelines, and internal rules relied upon in this determination, along with the reviewing clinician's credentials.
- The member's signed designation of this office as authorized representative is enclosed (Exhibit G).
- This appeal is submitted under the plan's claims procedures governed by 29 C.F.R. § 2560.503-1. Please provide, free of charge, copies of all documents, records, and other information relevant to this claim, including any internal rule, guideline, or protocol relied upon.
- The member reserves the right to independent external review if the adverse determination is upheld.

## 8. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 27447 | RT | Total knee arthroplasty | 1 |

Site of service: Ambulatory surgery center, Southlake Surgery Center. Anticipated date of service: 2026-10-08.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this appeal may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Erik Lindqvist, MD**\
Orthopedic Surgery — Adult Reconstruction · NPI 1639000037

*Electronically affirmed by Erik Lindqvist, MD on 2026-09-10 16:20 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Adverse benefit determination | 2026-09-03 | 2 |
| B | Office note with examination and scored KOOS JR *(new)* | 2026-07-09 | 4 |
| C | Nonoperative treatment records | 2024-04-15 to 2026-07-09 | 13 |
| D | Weight-bearing right knee radiograph report | 2026-07-09 | 1 |
| E | Laboratory results: HbA1c | 2026-08-14 | 1 |
| G | Authorized representative designation *(new)* | 2026-09-06 | 1 |

cc: Gloria J. Pennington
