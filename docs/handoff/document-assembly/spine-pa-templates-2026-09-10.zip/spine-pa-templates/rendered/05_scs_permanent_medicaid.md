![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Gulf Coast Community Health Plan — Member and Provider Appeals\
PO Box 0000, Example City, TX 77000\
Fax (800) 555-0155

**RE: Appeal of Adverse Benefit Determination — Texas Medicaid**

| Field | Value |
|---|---|
| Member | Teresa M. Villarreal |
| Date of birth | 1979-03-08 |
| Member ID | TXM-0048812205 |
| Authorization number | GCC-PA-26-30918 |
| Determination date | 2026-08-27 |
| Requested service | Permanent implantation of a spinal cord stimulator with two percutaneous leads and a pulse generator |
| Codes | 63650 ×2, 63685 |
| Diagnoses | M96.1, M54.17 |
| Site of service | Hospital outpatient department |
| Requesting physician | Jordan Reyes, MD · NPI 1497000011 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-09-29 |

Dear Appeals Reviewer,

With the written consent of my patient, Teresa M. Villarreal, I am requesting an appeal of the adverse benefit determination dated 2026-08-27 (reference GCC-PA-26-30918) denying permanent implantation of a spinal cord stimulator with two percutaneous leads and a pulse generator. The requested service is medically necessary and meets each applicable criterion of Spinal Cord Stimulation Clinical Policy (GCC-CP-122), as detailed below. I respectfully request that the determination be reversed.

## 1. Determination Being Addressed

The adverse benefit determination dated 2026-08-27 cites 2 reasons. Each is quoted verbatim and answered in the Response to Denial Reasons section.

The determination does not identify the specific criteria relied upon. This response therefore addresses Spinal Cord Stimulation Clinical Policy (GCC-CP-122, sample, effective 2026-01-01), which governs the requested service.

## 2. Clinical Summary

Ms. Villarreal is a 47-year-old woman with persistent left S1 radicular pain after L5-S1 fusion (postlaminectomy syndrome), first documented on 2023-10-12. Since her 2023 L5-S1 fusion, she has had constant burning pain in the left leg in an S1 distribution.

**Functional impact.** She cannot sit longer than 20 minutes, cannot work, and relies on family for childcare.

| ICD-10-CM | Description |
|---|---|
| M96.1 | Postlaminectomy syndrome, not elsewhere classified (primary) |
| M54.17 | Radiculopathy, lumbosacral region |

## 3. Implanted Spinal Neurostimulator Evidence

### Neurostimulation Indication

Neuropathic radicular pain persisting more than two years after a solidly fused L5-S1 arthrodesis, with no recurrent compression on imaging.

**Surgical options.** Her surgeon's evaluation on 2026-03-04 found a solid fusion without hardware failure or recurrent stenosis, so further surgery is not indicated.

**Contraindications screened.** She has no coagulopathy, active infection, or untreated substance use disorder, and she is able to operate the device.

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| NRS pain | 2026-06-30 | 8/10 | Severe pain | Exhibit B |
| Oswestry Disability Index | 2026-06-30 | 56% | Severe disability | Exhibit B |

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2024-02-05 to 2024-05-24 | 24 sessions | No durable benefit | Exhibit C |
| Gabapentinoids and duloxetine | 2023-12-01 to 2026-06-30 | Pregabalin 150 mg twice daily; duloxetine 60 mg daily | Partial relief; sedation limits dosing | Exhibit C |
| Cognitive behavioral therapy for pain | 2025-01-10 to 2025-04-11 | 12 sessions | Improved coping; pain unchanged | Exhibit C |

Documented conservative care spans 134 weeks (2023-12-01 to 2026-06-30), meeting the policy minimum of 26 weeks, and includes physical therapy, medication management, and behavioral therapy. Symptoms persisted despite this treatment.

### Psychological Evaluation

A licensed clinical psychologist completed a psychological evaluation on 2026-05-20 (Exhibit F) and cleared the patient for neurostimulation. The evaluation found no untreated major depression, psychosis, or substance use disorder, and realistic expectations for outcome.

### Trial Results

| Measure | Result | Source |
|---|---|---|
| Trial dates | 2026-07-14 to 2026-07-21 | Exhibit G |
| Pain relief | 70% (policy minimum 50%) | Exhibit G |
| Functional change | Sitting tolerance increased from 20 to 60 minutes; walked 30 minutes daily | Exhibit G |
| Medication change | Discontinued as-needed tramadol during the trial | Exhibit G |

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| BMI | 27.8 kg/m² | 2026-06-30 | — | Exhibit B |

### Site of Service

The procedure is planned in the hospital outpatient department setting at Trinity Valley Medical Center.

## 4. Criterion-by-Criterion Response

Each criterion below is quoted from Spinal Cord Stimulation Clinical Policy (GCC-CP-122).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| 1 | Chronic neuropathic pain for at least 6 months with failure of conservative therapy | Met | Pain since 2023; PT, pharmacotherapy, and CBT | Exhibit C |
| 2 | Further surgical intervention is not indicated | Met | Surgical evaluation 2026-03-04: solid fusion, no recurrent compression | Exhibit D |
| 3 | Psychological evaluation clearing the member for implantation | Met — documentation enclosed | Evaluation 2026-05-20, cleared | Exhibit F |
| 4 | Successful trial with at least 50% pain relief | Met | 70% relief with functional gains, 2026-07-14 to 2026-07-21 | Exhibit G |

Documentation for criterion 3 was not part of the original submission and is enclosed with this appeal.

## 5. Response to Denial Reasons

### Reason 1

> A psychological evaluation was not submitted.

**Response.** Documentation addressing this requirement was not part of the original submission and is now enclosed. Ms. Villarreal completed a psychological evaluation on 2026-05-20 and was cleared for implantation. The report was not included in the original request and is now enclosed.

**Enclosed documentation:** Psychological evaluation report (Exhibit F).

### Reason 2

> Documentation of a successful trial was not provided.

**Response.** This requirement was addressed in the original submission. The trial summary included in the original request documents 70% pain relief, a tripling of sitting tolerance, and discontinuation of as-needed tramadol.

**Where it is documented:** Spinal cord stimulator trial summary (Exhibit G).

## 6. Medical Necessity

Permanent neurostimulation is indicated for persistent neuropathic radicular pain after spinal fusion when further surgery is not indicated and a trial is successful. She meets each of these conditions.

**Alternatives considered.** Revision surgery is not indicated. Escalating pharmacotherapy is limited by sedation, and she wants to avoid long-term opioids.

**Consequences of delay or denial.** Continued disability and loss of the functional gains demonstrated during the trial.

## 7. Procedural Requests

- The member's written consent to this provider-filed appeal is enclosed (Exhibit H).
- If the plan upholds its determination, the member retains the right to request a State Fair Hearing through the Texas Medicaid agency.

## 8. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 63650 | — | Percutaneous implantation of neurostimulator electrode array, epidural | 2 |
| 63685 | — | Insertion or replacement of spinal neurostimulator pulse generator | 1 |

Site of service: Hospital outpatient department, Trinity Valley Medical Center. Anticipated date of service: 2026-09-29.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this appeal may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Jordan Reyes, MD**\
Interventional Spine and Pain Medicine · NPI 1497000011

*Electronically affirmed by Jordan Reyes, MD on 2026-09-10 11:40 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Adverse benefit determination | 2026-08-27 | 2 |
| B | Office note with NRS and ODI | 2026-06-30 | 3 |
| C | Conservative treatment records | 2023-12-01 to 2026-06-30 | 16 |
| D | Surgical evaluation and imaging | 2026-03-04 | 4 |
| F | Psychological evaluation report *(new)* | 2026-05-20 | 5 |
| G | Spinal cord stimulator trial summary | 2026-07-21 | 3 |
| H | Member written consent to provider-filed appeal *(new)* | 2026-09-05 | 1 |

cc: Teresa M. Villarreal
