![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Novitas Solutions, Inc. — Medicare Jurisdiction H — Prior Authorization, Hospital OPD Services\
[Verify current OPD PA address on the MAC website]\
Fax [Verify current OPD PA fax]

**RE: Resubmitted Prior Authorization Request — Prior UTN JH26082800451**

| Field | Value |
|---|---|
| Member | Margaret A. Ellison |
| Date of birth | 1954-04-19 |
| Member ID | 1EG4-TE5-MK72 |
| Prior UTN | JH26082800451 |
| Determination date | 2026-08-28 |
| Requested service | Bilateral lumbar radiofrequency ablation of the L4-L5 and L5-S1 facet joints |
| Codes | 64635-50, 64636-50 |
| Diagnoses | M47.816 |
| Levels | L4-L5, L5-S1 · Bilateral |
| Site of service | Hospital outpatient department |
| Requesting physician | Jordan Reyes, MD · NPI 1497000011 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-09-24 |

Dear Prior Authorization Reviewer,

This is a resubmission of the prior authorization request for bilateral lumbar radiofrequency ablation of the L4-L5 and L5-S1 facet joints for Margaret A. Ellison, which received a non-affirmed decision on 2026-08-28 (UTN JH26082800451). This resubmission answers each reason for non-affirmation in the decision letter and encloses documentation that was not part of the original request. The requested service meets each applicable requirement of LCD: Facet Joint Interventions for Pain Management (L38803), as detailed below.

## 1. Determination Being Addressed

The non-affirmation decision dated 2026-08-28 cites 2 reasons. Each is quoted verbatim and answered in the Response to Denial Reasons section.

The determination does not identify the specific criteria relied upon. This response therefore addresses LCD: Facet Joint Interventions for Pain Management (L38803, sample revision — verify current version in the Medicare Coverage Database), which governs the requested service.

## 2. Clinical Summary

Ms. Ellison is a 72-year-old woman with lumbar facet-mediated spondylosis without myelopathy or radiculopathy, first documented on 2025-11-03. She reports bilateral axial low back pain, worse with extension and prolonged standing, without radiation below the knee.

**Functional impact.** She cannot stand longer than 15 minutes, has stopped her part-time volunteer work, and needs help with grocery shopping.

| ICD-10-CM | Description |
|---|---|
| M47.816 | Spondylosis without myelopathy or radiculopathy, lumbar region (primary) |

## 3. Facet Joint Intervention Evidence

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| NRS pain | 2026-06-12 | 7/10 | Moderate to severe pain | Exhibit B |
| Oswestry Disability Index | 2026-06-12 | 42% | Severe disability (41–60%) | Exhibit B |

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2026-01-05 to 2026-03-20 | 22 supervised sessions, twice weekly | Pain 7/10 → 6/10; no functional gain | Exhibit C |
| Meloxicam | 2025-11-10 to 2026-06-30 | 15 mg daily | Partial relief; discontinued for dyspepsia | Exhibit G |
| Home exercise program | 2026-03-20 to 2026-08-01 | Daily core stabilization | No sustained improvement | Exhibit C |

Documented conservative care spans 37 weeks (2025-11-10 to 2026-08-01), meeting the policy minimum of 4 weeks, and includes physical therapy, medication management, and a home exercise program. Symptoms persisted despite this treatment.

### Neurological Examination

The examination on 2026-06-12 (Exhibit B) was performed to exclude radicular pain as the primary pain generator. Strength, reflexes, and sensation are symmetric and intact in both lower extremities, and straight-leg raise is negative bilaterally. There are no radicular findings.

| Motor | Side | Grade (0–5) |
|---|---|---|
| Hip flexion (L2–L3) | Bilateral | 5 |
| Ankle dorsiflexion (L4) | Bilateral | 5 |
| Great toe extension (L5) | Bilateral | 5 |
| Plantar flexion (S1) | Bilateral | 5 |

| Reflex | Side | Finding |
|---|---|---|
| Patellar | Bilateral | 2+, symmetric |
| Achilles | Bilateral | 2+, symmetric |

| Provocative test | Side | Result |
|---|---|---|
| Straight-leg raise | Bilateral | Negative |
| Facet loading (extension-rotation) | Bilateral | Positive, reproduces axial pain |

### Imaging and Clinical Concordance

| Study | Date | Level | Finding | Source |
|---|---|---|---|---|
| MRI lumbar spine | 2026-02-10 | L4-L5 | Bilateral facet arthropathy with joint effusions; no central or foraminal stenosis | Exhibit D |
| MRI lumbar spine | 2026-02-10 | L5-S1 | Bilateral facet hypertrophy; no neural compression | Exhibit D |

The most recent advanced imaging (MRI lumbar spine, 2026-02-10) was obtained 7 months before the anticipated date of service, within the policy's 24-month window.

### Level Selection

2 levels requested: L4-L5, L5-S1 (bilateral). This is within the policy limit of 2 levels per session.

| Level | Rationale | Source |
|---|---|---|
| L4-L5 | Facet arthropathy with effusion on MRI; concordant relief from both diagnostic blocks. | Exhibit D |
| L5-S1 | Facet hypertrophy on MRI; concordant relief from both diagnostic blocks. | Exhibit D |

### Diagnostic Medial Branch Blocks

2 diagnostic medial branch blocks targeting the requested levels each produced at least 80% relief.

| Block | Date | Target | Anesthetic | Peak relief | Duration of relief | Source |
|---|---|---|---|---|---|---|
| 1 | 2026-07-08 | Bilateral L3, L4 medial branches and L5 dorsal rami | Lidocaine 2% | 85% | 2 hours | Exhibit E |
| 2 | 2026-07-29 | Bilateral L3, L4 medial branches and L5 dorsal rami | Bupivacaine 0.5% | 90% | 5 hours | Exhibit F |

Relief duration tracked the expected duration of each anesthetic (shorter with lidocaine, longer with bupivacaine), supporting a true-positive response.

### Session Frequency

No prior sessions for this spinal region in the rolling 12 months before the anticipated date of service. This request would be session 1 of the 2 permitted.

### Site of Service

The procedure is planned in the hospital outpatient department setting at Trinity Valley Medical Center.

## 4. Criterion-by-Criterion Response

Each criterion below is quoted from LCD: Facet Joint Interventions for Pain Management (L38803).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| C1 | Moderate to severe axial pain of at least 3 months' duration with documented functional impairment on a validated scale | Met | NRS 7/10 and ODI 42% on 2026-06-12; pain since 2025-11-03 | Exhibit B |
| C2 | Failure of at least 4 weeks of conservative management | Met | Physical therapy, NSAID therapy, and home exercise, 2025-11-10 to 2026-08-01 | Exhibit C |
| C3 | Clinical findings implicate the facet joints; radicular pain is not the primary generator | Met | Positive facet loading; normal neurological examination; negative straight-leg raise | Exhibit B |
| C4 | Two diagnostic medial branch blocks, each producing at least 80% relief | Met — documentation enclosed | Block 1: 85% relief (2026-07-08). Block 2: 90% relief (2026-07-29), record newly enclosed | Exhibit F |
| C5 | No more than two joint levels treated per session | Met | Two levels requested (L4-L5, L5-S1) | — |
| C6 | No more than two RFA sessions per spinal region in a rolling 12-month period | Met | No prior RFA in the past 12 months | — |

Documentation for criterion C4 was not part of the original submission and is enclosed with this resubmission.

## 5. Response to Denial Reasons

### Reason 1 · Non-affirmation reason

> Documentation does not support that two medically necessary diagnostic medial branch blocks were performed, each with at least 80% relief.

**Response.** Documentation addressing this requirement was not part of the original submission and is now enclosed. The procedure note and post-block pain diary for the second block, performed on 2026-07-29, were not included in the original request. They document 90% relief lasting five hours with bupivacaine. The first block, on 2026-07-08, produced 85% relief lasting two hours with lidocaine.

**Enclosed documentation:** Second medial branch block procedure note and pain diary (Exhibit F).

### Reason 2 · Non-affirmation reason

> Documentation of at least 4 weeks of failed conservative care was not provided.

**Response.** This requirement was addressed in the original submission. The original request included physical therapy records documenting 22 supervised sessions from 2026-01-05 to 2026-03-20, followed by a home exercise program, alongside NSAID therapy that began on 2025-11-10.

**Where it is documented:** Physical therapy discharge summary, pages 3–5 (Exhibit C).

## 6. Medical Necessity

Two concordant diagnostic blocks identify the L4-L5 and L5-S1 facet joints as the primary pain generators. Radiofrequency ablation offers durable relief after nine months of failed conservative management.

**Alternatives considered.** Conservative care has plateaued. Intra-articular corticosteroid injections provide shorter relief and carry cumulative steroid exposure. Surgery is not indicated because there is no instability or neural compression.

**Consequences of delay or denial.** Continued functional decline, deconditioning, and likely escalation to chronic opioid therapy, which carries particular risk at her age.

## 7. Procedural Requests

- This request is submitted under the resubmission process of the hospital outpatient department prior authorization program. Provisional affirmation is requested so that the associated claim can be submitted with the new UTN.

## 8. Requested Action

Please provisionally affirm the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 64635 | 50 | Radiofrequency ablation, lumbar or sacral facet, single joint | 1 |
| 64636 | 50 | Radiofrequency ablation, lumbar or sacral facet, each additional joint | 1 |

Site of service: Hospital outpatient department, Trinity Valley Medical Center. Anticipated date of service: 2026-09-24.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this resubmission may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Jordan Reyes, MD**\
Interventional Spine and Pain Medicine · NPI 1497000011

*Electronically affirmed by Jordan Reyes, MD on 2026-09-10 14:32 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Non-affirmation decision letter | 2026-08-28 | 2 |
| B | Office visit note with neurological examination, NRS, and ODI | 2026-06-12 | 4 |
| C | Physical therapy records and home exercise program | 2026-01-05 to 2026-08-01 | 12 |
| D | MRI lumbar spine report | 2026-02-10 | 2 |
| E | First medial branch block procedure note and pain diary | 2026-07-08 | 3 |
| F | Second medial branch block procedure note and pain diary *(new)* | 2026-07-29 | 4 |
| G | Medication history | 2025-11-10 to 2026-08-01 | 2 |

cc: Margaret A. Ellison
