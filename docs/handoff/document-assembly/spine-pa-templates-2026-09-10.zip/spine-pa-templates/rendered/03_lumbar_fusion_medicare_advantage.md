![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Bluebonnet Medicare Advantage — Appeals and Grievances — Part C Reconsiderations\
PO Box 0000, Example City, TX 75000\
Fax (800) 555-0177

**RE: Request for Reconsideration of Organization Determination**

| Field | Value |
|---|---|
| Member | Robert L. Castañeda |
| Date of birth | 1955-02-14 |
| Member ID | BBMA-5520-0931 |
| Organization determination | OD-2026-448120 |
| Determination date | 2026-08-31 |
| Requested service | L4-L5 decompression with instrumented posterolateral and posterior interbody fusion |
| Codes | 22633, 22840, 22853, 20936 |
| Diagnoses | M43.16, M48.062 |
| Levels | L4-L5 |
| Site of service | Inpatient hospital |
| Requesting physician | Adaeze Okafor, MD · NPI 1528000025 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-10-06 |

Dear Reconsideration Reviewer,

On behalf of my patient, Robert L. Castañeda, I am requesting reconsideration of the organization determination dated 2026-08-31 (reference OD-2026-448120) denying L4-L5 decompression with instrumented posterolateral and posterior interbody fusion. The requested service is medically necessary and meets each applicable criterion of Lumbar Spinal Fusion Medical Policy (MP-SPINE-014), as detailed below. I respectfully request that the determination be reversed.

## 1. Determination Being Addressed

The organization determination dated 2026-08-31 cites 2 reasons. Each is quoted verbatim and answered in the Response to Denial Reasons section.

The determination does not identify the specific criteria relied upon. This response therefore addresses Lumbar Spinal Fusion Medical Policy (MP-SPINE-014, sample, revised 2026-03), which governs the requested service.

## 2. Clinical Summary

Mr. Castañeda is a 71-year-old man with grade I degenerative spondylolisthesis at L4-L5 with dynamic instability and severe stenosis, first documented on 2025-10-15. He reports low back pain and left leg pain in an L5 distribution, with neurogenic claudication limiting walking to one block.

**Functional impact.** He can no longer walk his dog or shop without a motorized cart, and he has given up golf.

| ICD-10-CM | Description |
|---|---|
| M43.16 | Spondylolisthesis, lumbar region (primary) |
| M48.062 | Spinal stenosis, lumbar region, with neurogenic claudication |

## 3. Lumbar Fusion Evidence

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| Oswestry Disability Index | 2025-12-01 | 38% | Moderate disability | Exhibit B |
| Oswestry Disability Index | 2026-07-28 | 52% | Severe disability | Exhibit B |

ODI worsened from 38% to 52% despite eight months of conservative care.

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2025-12-01 to 2026-02-20 | 18 sessions, flexion-based program | Transient improvement; relapse within weeks | Exhibit C |
| NSAIDs and gabapentin | 2025-10-20 to 2026-07-28 | Celecoxib 200 mg daily; gabapentin titrated to 900 mg daily | Partial relief of leg pain | Exhibit C |
| Transforaminal epidural steroid injections | 2026-03-12 to 2026-05-14 | Two injections, left L4-L5 | Relief lasting under three weeks each time | Exhibit C |

Documented conservative care spans 40 weeks (2025-10-20 to 2026-07-28), meeting the policy minimum of 12 weeks, and includes physical therapy, medication management, and injection therapy. Symptoms persisted despite this treatment.

### Neurological Examination

The examination on 2026-07-28 (Exhibit B) documents objective neurological deficit corresponding to the compressed levels. Findings include left great toe extension weakness and diminished sensation over the left dorsal foot.

| Motor | Side | Grade (0–5) |
|---|---|---|
| Great toe extension (L5) | Left | 4 |
| Ankle dorsiflexion (L4) | Left | 5 |

| Reflex | Side | Finding |
|---|---|---|
| Patellar | Bilateral | 2+ |

| Sensory distribution | Side | Finding |
|---|---|---|
| L5 dermatome | Left | Diminished to pinprick |

### Imaging and Clinical Concordance

| Study | Date | Level | Finding | Source |
|---|---|---|---|---|
| MRI lumbar spine | 2026-04-15 | L4-L5 | Grade I anterolisthesis with severe central and left lateral recess stenosis | Exhibit D |
| Flexion-extension radiographs | 2026-04-15 | L4-L5 | 4.5 mm sagittal translation between flexion and extension | Exhibit E |

Each treated level correlates with the examination and the patient's symptom distribution:

| Level | Imaging finding | Examination finding | Symptom correlation |
|---|---|---|---|
| L4-L5 | Severe stenosis, left lateral recess | Left EHL 4/5, left L5 sensory loss | Left L5 radicular pain, claudication |

The most recent advanced imaging (MRI lumbar spine, 2026-04-15) was obtained 5 months before the anticipated date of service, within the policy's 12-month window.

### Fusion Indication

**Indication:** Degenerative spondylolisthesis with dynamic instability.

| Measurement | Value | Date | Source |
|---|---|---|---|
| Sagittal translation, flexion to extension | 4.5 mm | 2026-04-15 | Exhibit E |
| Slip grade (Meyerding) | Grade I (18%) | 2026-04-15 | Exhibit E |

**Why decompression alone is inadequate.** Adequate decompression of the left lateral recess requires partial facetectomy at a segment that already translates 4.5 mm. Decompression alone would further destabilize the segment and risk slip progression and recurrent stenosis.

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| Nicotine | Former, quit 2026-05-01; urine cotinine negative on 2026-08-20 | 2026-08-20 | Nicotine-free ≥ 6 weeks | Exhibit F |
| BMI | 32.1 kg/m² | 2026-07-28 | ≤ 40 | Exhibit B |
| HbA1c | 6.9% | 2026-08-20 | ≤ 8.0% | Exhibit F |

### Level Selection

1 level requested: L4-L5. This is within the policy limit of 2 levels per procedure.

| Level | Rationale | Source |
|---|---|---|
| L4-L5 | Grade I degenerative spondylolisthesis with 4.5 mm dynamic translation and severe stenosis; concordant L5 deficit. | Exhibit D |

**Adjacent levels not included**

- **L3-L4:** Mild disc bulge without stenosis or instability.

### Instrumentation, Devices, and Graft

| Code | Description | Units | Clinical justification |
|---|---|---|---|
| 22840 | Posterior non-segmental instrumentation | 1 | Bilateral L4–L5 pedicle screw fixation stabilizes the dynamically unstable segment. |
| 22853 | Insertion of interbody biomechanical device, each interspace | 1 | An interbody cage restores disc height and indirectly decompresses the foramina. |
| 20936 | Autograft, local, same incision, for spine surgery | 1 | Local autograft from the decompression is used for arthrodesis, avoiding a separate harvest site. |

### Site of Service

Inpatient admission is requested. Instrumented fusion in a 71-year-old with type 2 diabetes requires inpatient care.

- Expected stay spans at least two midnights for pain control, mobilization, and drain management.
- Diabetes requires perioperative glucose management.

## 4. Criterion-by-Criterion Response

Each criterion below is quoted from Lumbar Spinal Fusion Medical Policy (MP-SPINE-014).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| C1 | Spondylolisthesis with documented instability on flexion-extension imaging | Met | 4.5 mm translation on flexion-extension radiographs | Exhibit E |
| C2 | At least 12 weeks of conservative care including physical therapy and medication | Met | PT, medication, and two epidural injections from 2025-10-20 to 2026-07-28 | Exhibit C |
| C3 | Neurological deficit or neurogenic claudication concordant with imaging | Met | Left L5 motor and sensory deficit; claudication at one block | Exhibit B |
| C4 | Verified nicotine abstinence for at least 6 weeks before surgery | Met — documentation enclosed | Quit 2026-05-01; urine cotinine negative 2026-08-20 | Exhibit F |
| C5 | BMI and glycemic control within surgical safety thresholds | Met | BMI 32.1; HbA1c 6.9% | Exhibit F |

Documentation for criterion C4 was not part of the original submission and is enclosed with this reconsideration request.

## 5. Response to Denial Reasons

### Reason 1

> Nicotine abstinence has not been verified.

**Response.** Documentation addressing this requirement was not part of the original submission and is now enclosed. Mr. Castañeda stopped smoking on 2026-05-01. A urine cotinine test on 2026-08-20 was negative, and the report is enclosed. By the anticipated date of service, he will have been nicotine-free for 22 weeks.

**Enclosed documentation:** Urine cotinine report and laboratory panel (Exhibit F).

### Reason 2

> Imaging does not demonstrate instability at the requested level.

**Response.** This requirement was addressed in the original submission. The flexion-extension radiograph report included in the original request documents 4.5 mm of sagittal translation at L4-L5.

**Where it is documented:** Flexion-extension radiograph report (Exhibit E).

## 6. Medical Necessity

Instrumented fusion at L4-L5 addresses both the neural compression causing his L5 deficit and claudication and the dynamic instability that makes decompression alone unsafe.

**Alternatives considered.** Decompression alone risks iatrogenic instability and slip progression. Further injections have produced diminishing, short-lived relief.

**Consequences of delay or denial.** Progressive motor deficit, further loss of walking tolerance, and deconditioning that raises surgical risk later.

## 7. Procedural Requests

- Please provide copies of the specific criteria, guidelines, and internal rules relied upon in this determination, along with the reviewing clinician's credentials.
- Please ensure that this reconsideration request is reviewed by a clinician in orthopedic spine surgery or a closely related specialty.
- The determination applied the plan's internal coverage criteria. Under 42 C.F.R. § 422.101(b)(6), a Medicare Advantage plan may apply internal criteria only when Medicare coverage criteria are not fully established, and must make the supporting evidence publicly accessible. Please identify the Medicare coverage criteria applicable to this service, or the public evidence summary supporting the internal criteria used.
- If the plan affirms its adverse determination in whole or in part, please forward the case file to the Independent Review Entity as required for Medicare Advantage reconsiderations, and notify the member and this office.

## 8. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 22633 | — | Combined posterolateral and posterior interbody arthrodesis, lumbar, single interspace | 1 |
| 22840 | — | Posterior non-segmental instrumentation | 1 |
| 22853 | — | Insertion of interbody biomechanical device, each interspace | 1 |
| 20936 | — | Autograft, local, same incision, for spine surgery | 1 |

Site of service: Inpatient hospital, Trinity Valley Medical Center. Anticipated date of service: 2026-10-06.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this reconsideration request may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Adaeze Okafor, MD**\
Orthopedic Spine Surgery · NPI 1528000025

*Electronically affirmed by Adaeze Okafor, MD on 2026-09-10 09:15 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Organization determination notice | 2026-08-31 | 2 |
| B | Office notes with neurological examination and ODI | 2025-12-01 to 2026-07-28 | 8 |
| C | Physical therapy, medication, and injection records | 2025-10-20 to 2026-07-28 | 14 |
| D | MRI lumbar spine report | 2026-04-15 | 2 |
| E | Flexion-extension radiograph report | 2026-04-15 | 1 |
| F | Laboratory results: urine cotinine and HbA1c *(new)* | 2026-08-20 | 2 |

cc: Robert L. Castañeda
