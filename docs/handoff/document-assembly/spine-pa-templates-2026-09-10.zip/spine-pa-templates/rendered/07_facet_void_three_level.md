# INTERNAL — Letter Generation Halted

**Do not send.** This case failed 4 pre-send gates. No payer-facing letter was generated.

| Field | Value |
|---|---|
| Patient | Harold P. Nguyen · Member ID 7TR2-QX8-NN41 |
| Letter kind | `denial_response` |
| Payer / program | Novitas Solutions, Inc. — Medicare Jurisdiction H · `medicare_ffs_opd` |
| Prior UTN | JH26090200112 |
| Requested codes | 64493-50, 64494-50, 64495-50 |
| Procedure family | Facet Joint Intervention (`diagnostic_block`) |

## Blocking Items

| # | Type | Source | Reference | Detail | Recommended action |
|---|---|---|---|---|---|
| 1 | OPEN GAP | `criterion` | C2 | Failure of at least 4 weeks of conservative management — no supporting documentation on file. | Obtain documentation, update the case record, and regenerate. |
| 2 | VOID | `criterion` | C5 | No more than two joint levels treated per session — Three levels requested | Revise the request, consider a clinical exception request, or begin patient financial counseling. |
| 3 | VOID | `code_rule` | 64495 | Three or more facet levels in one session are non-covered under the harmonized Medicare facet joint intervention LCDs; CMS removed these codes from OPD prior authorization because every request would be non-affirmed. | Do not resubmit as requested. Reduce to no more than two levels and submit a new request, or evaluate an alternative service. |
| 4 | VOID | `policy_threshold` | max_levels | 3 levels requested; the policy permits at most 2. | Reduce the number of levels or request a clinical exception. |

## Next Steps

- **3 void items.** Documentation cannot cure a void item, so submitting the request unchanged will fail. Revise the request itself (codes, levels, or service), consider a clinical exception request, or begin patient financial counseling.
- **1 open gap.** Obtain the missing documentation, update the case record, and regenerate. Never argue a criterion as met without evidence.
- This memo is replaced by the letter automatically once every gate passes.
