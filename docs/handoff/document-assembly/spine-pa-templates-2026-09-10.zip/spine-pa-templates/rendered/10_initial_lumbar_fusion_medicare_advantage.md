![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Bluebonnet Medicare Advantage — Utilization Management — Organization Determinations\
PO Box 0000, Example City, TX 75000\
Fax (800) 555-0177

**RE: Request for Pre-Service Organization Determination**

| Field | Value |
|---|---|
| Member | Robert L. Castañeda |
| Date of birth | 1955-02-14 |
| Member ID | BBMA-5520-0931 |
| Requested service | L4-L5 decompression with instrumented posterolateral and posterior interbody fusion |
| Codes | 22633, 22840, 22853, 20936 |
| Diagnoses | M43.16, M48.062 |
| Levels | L4-L5 |
| Site of service | Inpatient hospital |
| Requesting physician | Adaeze Okafor, MD · NPI 1528000025 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-10-06 |

Dear Utilization Management Reviewer,

On behalf of my patient, Robert L. Castañeda, I am requesting a pre-service organization determination for L4-L5 decompression with instrumented posterolateral and posterior interbody fusion. The service is medically necessary and meets each applicable criterion of Lumbar Spinal Fusion Medical Policy (MP-SPINE-014), as documented below.

## 1. Request Summary

This request is for L4-L5 decompression with instrumented posterolateral and posterior interbody fusion, planned for 2026-10-06 in the inpatient hospital setting at Trinity Valley Medical Center. It is governed by Lumbar Spinal Fusion Medical Policy (MP-SPINE-014, sample, revised 2026-03).

Every criterion in that policy is addressed in the Criterion-by-Criterion Documentation section. Each supporting record is enclosed and cited by exhibit, so the request can be decided on the documents submitted.

## 2. Clinical Summary

Mr. Castañeda is a 71-year-old man with grade I degenerative spondylolisthesis at L4-L5 with dynamic instability and severe stenosis, first documented on 2025-10-15. He reports low back pain and left leg pain in an L5 distribution, with neurogenic claudication limiting walking to one block.

**Functional impact.** He can no longer walk his dog or shop without a motorized cart, and he has given up golf.

| ICD-10-CM | Description |
|---|---|
| M43.16 | Spondylolisthesis, lumbar region (primary) |
| M48.062 | Spinal stenosis, lumbar region, with neurogenic claudication |

## 3. Lumbar Fusion Evidence

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| Oswestry Disability Index | 2025-12-01 | 38% | Moderate disability | Exhibit A |
| Oswestry Disability Index | 2026-07-28 | 52% | Severe disability | Exhibit A |

ODI worsened from 38% to 52% despite eight months of conservative care.

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2025-12-01 to 2026-02-20 | 18 sessions, flexion-based program | Transient improvement; relapse within weeks | Exhibit B |
| NSAIDs and gabapentin | 2025-10-20 to 2026-07-28 | Celecoxib 200 mg daily; gabapentin titrated to 900 mg daily | Partial relief of leg pain | Exhibit B |
| Transforaminal epidural steroid injections | 2026-03-12 to 2026-05-14 | Two injections, left L4-L5 | Relief lasting under three weeks each time | Exhibit B |

Documented conservative care spans 40 weeks (2025-10-20 to 2026-07-28), meeting the policy minimum of 12 weeks, and includes physical therapy, medication management, and injection therapy. Symptoms persisted despite this treatment.

### Neurological Examination

The examination on 2026-07-28 (Exhibit A) documents objective neurological deficit corresponding to the compressed levels. Findings include left great toe extension weakness and diminished sensation over the left dorsal foot.

| Motor | Side | Grade (0–5) |
|---|---|---|
| Great toe extension (L5) | Left | 4 |
| Ankle dorsiflexion (L4) | Left | 5 |

| Reflex | Side | Finding |
|---|---|---|
| Patellar | Bilateral | 2+ |

| Sensory distribution | Side | Finding |
|---|---|---|
| L5 dermatome | Left | Diminished to pinprick |

### Imaging and Clinical Concordance

| Study | Date | Level | Finding | Source |
|---|---|---|---|---|
| MRI lumbar spine | 2026-04-15 | L4-L5 | Grade I anterolisthesis with severe central and left lateral recess stenosis | Exhibit C |
| Flexion-extension radiographs | 2026-04-15 | L4-L5 | 4.5 mm sagittal translation between flexion and extension | Exhibit D |

Each treated level correlates with the examination and the patient's symptom distribution:

| Level | Imaging finding | Examination finding | Symptom correlation |
|---|---|---|---|
| L4-L5 | Severe stenosis, left lateral recess | Left EHL 4/5, left L5 sensory loss | Left L5 radicular pain, claudication |

The most recent advanced imaging (MRI lumbar spine, 2026-04-15) was obtained 5 months before the anticipated date of service, within the policy's 12-month window.

### Fusion Indication

**Indication:** Degenerative spondylolisthesis with dynamic instability.

| Measurement | Value | Date | Source |
|---|---|---|---|
| Sagittal translation, flexion to extension | 4.5 mm | 2026-04-15 | Exhibit D |
| Slip grade (Meyerding) | Grade I (18%) | 2026-04-15 | Exhibit D |

**Why decompression alone is inadequate.** Adequate decompression of the left lateral recess requires partial facetectomy at a segment that already translates 4.5 mm. Decompression alone would further destabilize the segment and risk slip progression and recurrent stenosis.

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| Nicotine | Former, quit 2026-05-01; urine cotinine negative on 2026-08-20 | 2026-08-20 | Nicotine-free ≥ 6 weeks | Exhibit E |
| BMI | 32.1 kg/m² | 2026-07-28 | ≤ 40 | Exhibit A |
| HbA1c | 6.9% | 2026-08-20 | ≤ 8.0% | Exhibit E |

### Level Selection

1 level requested: L4-L5. This is within the policy limit of 2 levels per procedure.

| Level | Rationale | Source |
|---|---|---|
| L4-L5 | Grade I degenerative spondylolisthesis with 4.5 mm dynamic translation and severe stenosis; concordant L5 deficit. | Exhibit C |

**Adjacent levels not included**

- **L3-L4:** Mild disc bulge without stenosis or instability.

### Instrumentation, Devices, and Graft

| Code | Description | Units | Clinical justification |
|---|---|---|---|
| 22840 | Posterior non-segmental instrumentation | 1 | Bilateral L4–L5 pedicle screw fixation stabilizes the dynamically unstable segment. |
| 22853 | Insertion of interbody biomechanical device, each interspace | 1 | An interbody cage restores disc height and indirectly decompresses the foramina. |
| 20936 | Autograft, local, same incision, for spine surgery | 1 | Local autograft from the decompression is used for arthrodesis, avoiding a separate harvest site. |

### Site of Service

Inpatient admission is requested. Instrumented fusion in a 71-year-old with type 2 diabetes requires inpatient care.

- Expected stay spans at least two midnights for pain control, mobilization, and drain management.
- Diabetes requires perioperative glucose management.

## 4. Criterion-by-Criterion Documentation

Each criterion below is quoted from Lumbar Spinal Fusion Medical Policy (MP-SPINE-014).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| C1 | Spondylolisthesis with documented instability on flexion-extension imaging | Met | 4.5 mm translation on flexion-extension radiographs | Exhibit D |
| C2 | At least 12 weeks of conservative care including physical therapy and medication | Met | PT, medication, and two epidural injections from 2025-10-20 to 2026-07-28 | Exhibit B |
| C3 | Neurological deficit or neurogenic claudication concordant with imaging | Met | Left L5 motor and sensory deficit; claudication at one block | Exhibit A |
| C4 | Verified nicotine abstinence for at least 6 weeks before surgery | Met | Quit 2026-05-01; urine cotinine negative 2026-08-20 | Exhibit E |
| C5 | BMI and glycemic control within surgical safety thresholds | Met | BMI 32.1; HbA1c 6.9% | Exhibit E |

## 5. Medical Necessity

Instrumented fusion at L4-L5 addresses both the neural compression causing his L5 deficit and claudication and the dynamic instability that makes decompression alone unsafe.

**Alternatives considered.** Decompression alone risks iatrogenic instability and slip progression. Further injections have produced diminishing, short-lived relief.

**Consequences of delay or denial.** Progressive motor deficit, further loss of walking tolerance, and deconditioning that raises surgical risk later.

## 6. Submission Notes

- Please issue the determination within the Medicare Advantage timeframe that applies under CMS-0057-F: 7 calendar days for a standard request. Please send written notice to the member and to this office.
- Where Medicare coverage criteria are fully established for this service, 42 C.F.R. § 422.101(b)(6) requires the plan to apply them. If the plan applies internal criteria instead, please identify them and the publicly available evidence supporting them.
- If this request cannot be approved as submitted, please arrange a peer-to-peer discussion with a clinician in orthopedic spine surgery or a closely related specialty before an adverse determination is issued.

## 7. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 22633 | — | Combined posterolateral and posterior interbody arthrodesis, lumbar, single interspace | 1 |
| 22840 | — | Posterior non-segmental instrumentation | 1 |
| 22853 | — | Insertion of interbody biomechanical device, each interspace | 1 |
| 20936 | — | Autograft, local, same incision, for spine surgery | 1 |

Site of service: Inpatient hospital, Trinity Valley Medical Center. Anticipated date of service: 2026-10-06.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this request may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Adaeze Okafor, MD**\
Orthopedic Spine Surgery · NPI 1528000025

*Electronically affirmed by Adaeze Okafor, MD on 2026-09-10 09:15 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Office notes with neurological examination and ODI | 2025-12-01 to 2026-07-28 | 8 |
| B | Physical therapy, medication, and injection records | 2025-10-20 to 2026-07-28 | 14 |
| C | MRI lumbar spine report | 2026-04-15 | 2 |
| D | Flexion-extension radiograph report | 2026-04-15 | 1 |
| E | Laboratory results: urine cotinine and HbA1c | 2026-08-20 | 2 |

cc: Robert L. Castañeda
