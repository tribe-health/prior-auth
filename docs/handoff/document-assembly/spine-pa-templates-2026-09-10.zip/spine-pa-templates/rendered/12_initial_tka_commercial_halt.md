# INTERNAL — Letter Generation Halted

**Do not send.** This case failed 2 pre-send gates. No payer-facing letter was generated.

| Field | Value |
|---|---|
| Patient | Gloria J. Pennington · Member ID LSE771023488 |
| Letter kind | `initial_request` |
| Payer / program | Lone Star Employer Health Plan · `commercial` |
| Requested codes | 27447-RT |
| Procedure family | Total Joint Arthroplasty |

## Blocking Items

| # | Type | Source | Reference | Detail | Recommended action |
|---|---|---|---|---|---|
| 1 | OPEN GAP | `criterion` | 4 | BMI of 40 or less and HbA1c of 8.0% or less — no supporting documentation on file. | Obtain documentation, update the case record, and regenerate. |
| 2 | OPEN GAP | `policy_threshold` | HbA1c | HbA1c 8.6 exceeds the policy threshold of 8. | Document optimization or request a clinical exception, then regenerate. |

## Next Steps

- **2 open gaps.** Obtain the missing documentation, update the case record, and regenerate. Never argue a criterion as met without evidence.
- This memo is replaced by the letter automatically once every gate passes.
