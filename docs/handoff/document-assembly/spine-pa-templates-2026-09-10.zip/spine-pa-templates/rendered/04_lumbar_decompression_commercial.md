![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Prairie Mutual Health Insurance — Utilization Review Appeals\
PO Box 0000, Example City, TX 75000\
Fax (800) 555-0166

**RE: Level 1 Internal Appeal of Adverse Benefit Determination**

| Field | Value |
|---|---|
| Member | Linda K. Harmon |
| Date of birth | 1961-07-30 |
| Member ID | PMH-3309-1175 |
| Group / plan | IND-TX / Individual Silver |
| Authorization number | PMH-UR-2026-77410 |
| Determination date | 2026-09-02 |
| Requested service | L4-L5 laminectomy with bilateral foraminotomy |
| Codes | 63047 |
| Diagnoses | M48.062 |
| Levels | L4-L5 |
| Site of service | Ambulatory surgery center |
| Requesting physician | Adaeze Okafor, MD · NPI 1528000025 |
| Facility | Southlake Surgery Center · NPI 1851000051 |
| Anticipated date of service | 2026-10-01 |

Dear Appeals Reviewer,

I am submitting this appeal on behalf of my patient, Linda K. Harmon, regarding the adverse determination dated 2026-09-02 (reference PMH-UR-2026-77410) denying L4-L5 laminectomy with bilateral foraminotomy. The requested service is medically necessary and meets each applicable criterion of Lumbar Decompression Surgery (PMH-MP-0310), as detailed below. I respectfully request that the determination be reversed and the service authorized.

## 1. Determination Being Addressed

The adverse determination dated 2026-09-02 cites 2 reasons. Each is quoted verbatim and answered in the Response to Denial Reasons section.

The determination does not identify the specific criteria relied upon. This response therefore addresses Lumbar Decompression Surgery (PMH-MP-0310, sample, effective 2026-02-01), which governs the requested service.

## 2. Clinical Summary

Ms. Harmon is a 65-year-old woman with lumbar spinal stenosis at L4-L5 with neurogenic claudication, first documented on 2025-09-01. She reports bilateral buttock and thigh pain with walking, relieved by sitting or leaning forward.

**Functional impact.** Her walking tolerance is under two blocks, and she has stopped her part-time job as a retail associate.

| ICD-10-CM | Description |
|---|---|
| M48.062 | Spinal stenosis, lumbar region, with neurogenic claudication (primary) |

## 3. Lumbar Decompression Evidence

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| Oswestry Disability Index | 2026-08-05 | 46% | Severe disability | Exhibit B |
| Zurich Claudication Questionnaire, symptom severity | 2026-08-05 | 3.4 / 5 | Marked symptom severity | Exhibit B |

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2025-10-06 to 2026-01-16 | 20 sessions, flexion-based | No improvement in walking tolerance | Exhibit C |
| NSAIDs | 2025-09-15 to 2026-08-05 | Ibuprofen 600 mg three times daily as needed | Minimal relief | Exhibit C |
| Interlaminar epidural steroid injection | 2026-03-10 to 2026-03-10 | Single injection, L4-L5 | Four weeks of partial relief | Exhibit C |

Documented conservative care spans 46 weeks (2025-09-15 to 2026-08-05), meeting the policy minimum of 12 weeks, and includes physical therapy, medication management, and injection therapy. Symptoms persisted despite this treatment.

### Neurological Examination

The examination on 2026-08-05 (Exhibit B) documents objective neurological deficit corresponding to the compressed levels. Strength is preserved, with diminished bilateral Achilles reflexes and a stooped posture on ambulation.

| Reflex | Side | Finding |
|---|---|---|
| Achilles | Bilateral | 1+ |

| Provocative test | Side | Result |
|---|---|---|
| Treadmill walking test | — | Symptoms reproduced at 3 minutes |

### Imaging and Clinical Concordance

| Study | Date | Level | Finding | Source |
|---|---|---|---|---|
| MRI lumbar spine | 2026-06-18 | L4-L5 | Severe central stenosis (cross-sectional area 55 mm²) with bilateral lateral recess narrowing | Exhibit D |

The most recent advanced imaging (MRI lumbar spine, 2026-06-18) was obtained 3 months before the anticipated date of service, within the policy's 12-month window.

### Neurogenic Claudication

| Feature | Finding | Source |
|---|---|---|
| Walking tolerance | Under two blocks; symptoms reproduced at 3 minutes on treadmill | Exhibit B |
| Positional features | Relief with sitting and forward flexion (shopping-cart sign) | Exhibit B |
| Vascular claudication excluded | Ankle-brachial index 1.05 right, 1.08 left | Exhibit E |

### Level Selection

1 level requested: L4-L5. This is within the policy limit of 2 levels per procedure.

| Level | Rationale | Source |
|---|---|---|
| L4-L5 | Severe central stenosis with bilateral lateral recess narrowing; no instability. | Exhibit D |

### Site of Service

The procedure is planned in the ambulatory surgery center setting at Southlake Surgery Center. She has no comorbidities requiring inpatient care, and same-day discharge is expected.

## 4. Criterion-by-Criterion Response

Each criterion below is quoted from Lumbar Decompression Surgery (PMH-MP-0310).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| 1 | Neurogenic claudication or radiculopathy with imaging-confirmed stenosis | Met | Claudication at under two blocks; MRI severe central stenosis | Exhibit D |
| 2 | At least 12 weeks of conservative care including physical therapy and medication | Met | PT, NSAIDs, and ESI, 2025-09-15 to 2026-08-05 | Exhibit C |
| 3 | Vascular claudication excluded | Met | Normal ankle-brachial indices | Exhibit E |

## 5. Response to Denial Reasons

### Reason 1

> The member has not completed 12 weeks of conservative therapy.

**Response.** This requirement was addressed in the original submission. The records show 20 physical therapy sessions from 2025-10-06 to 2026-01-16, continuous NSAID therapy since 2025-09-15, and an epidural injection on 2026-03-10. That is more than 46 weeks of conservative care.

**Where it is documented:** Physical therapy discharge summary and medication record (Exhibit C).

### Reason 2

> Flexion-extension radiographs demonstrating stability were not provided.

**Response.** This requirement does not apply to this patient. Flexion-extension imaging is required to evaluate instability when fusion is proposed. This request is for decompression alone, at a level with no spondylolisthesis on MRI, so the requirement does not apply.

The policy provides:

> (Sample language) Flexion-extension radiographs are required when lumbar fusion is requested.

## 6. Medical Necessity

Laminectomy at L4-L5 directly relieves the compression causing her neurogenic claudication. Nearly a year of conservative care has failed.

**Alternatives considered.** Further injections produced only four weeks of relief. Fusion is not indicated because there is no instability.

**Consequences of delay or denial.** Continued loss of walking tolerance and progressive deconditioning.

## 7. Procedural Requests

- Please ensure that this appeal is reviewed by a clinician in orthopedic spine surgery or a closely related specialty.
- This appeal is also submitted under Texas Insurance Code Chapter 4201 (utilization review).
- The member reserves the right to independent external review if the adverse determination is upheld.

## 8. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 63047 | — | Laminectomy, facetectomy and foraminotomy, lumbar, single segment | 1 |

Site of service: Ambulatory surgery center, Southlake Surgery Center. Anticipated date of service: 2026-10-01.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this appeal may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Adaeze Okafor, MD**\
Orthopedic Spine Surgery · NPI 1528000025

*Electronically affirmed by Adaeze Okafor, MD on 2026-09-10 10:05 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Adverse determination letter | 2026-09-02 | 2 |
| B | Office note with examination, ODI, and ZCQ | 2026-08-05 | 4 |
| C | Physical therapy, medication, and injection records | 2025-09-15 to 2026-08-05 | 11 |
| D | MRI lumbar spine report | 2026-06-18 | 2 |
| E | Ankle-brachial index report | 2026-07-22 | 1 |

cc: Linda K. Harmon
