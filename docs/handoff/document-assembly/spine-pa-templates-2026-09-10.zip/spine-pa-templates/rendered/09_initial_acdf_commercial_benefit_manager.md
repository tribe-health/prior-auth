![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Summit Specialty Review — Spine Prior Authorization\
On behalf of Lone Star Employer Health Plan\
PO Box 0000, Example City, TX 75000\
Fax (800) 555-0199

**RE: Pre-Service Prior Authorization Request** — **EXPEDITED REVIEW REQUESTED**

| Field | Value |
|---|---|
| Member | Daniel R. Whitfield |
| Date of birth | 1968-11-02 |
| Member ID | LSE884201937 |
| Group / plan | EMP-44120 / Choice PPO |
| Requested service | Anterior cervical discectomy and fusion at C5-C6 and C6-C7 |
| Codes | 22551, 22552, 22845, 22853 ×2, 20930 |
| Diagnoses | M50.020, M50.123 |
| Levels | C5-C6, C6-C7 |
| Site of service | Inpatient hospital |
| Requesting physician | Adaeze Okafor, MD · NPI 1528000025 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-09-22 |

Dear Utilization Management Reviewer,

I am requesting prior authorization of anterior cervical discectomy and fusion at C5-C6 and C6-C7 for my patient, Daniel R. Whitfield. The service is medically necessary and meets each applicable criterion of Spine Surgery Guidelines: Cervical Fusion (SSR-CERV-2026.1), as documented below.

**Request for expedited review.** Applying the standard review timeframe could seriously jeopardize Mr. Whitfield's life or health, or ability to regain maximum function. Mr. Whitfield has progressive cervical myelopathy with intramedullary cord signal change. His mJOA score has declined three points in ten weeks, and he has fallen twice. Further delay risks permanent neurological injury. As the treating physician, I certify that expedited review is warranted.

## 1. Request Summary

This request is directed to Summit Specialty Review, which administers prior authorization for cervical fusion with disc removal on behalf of Lone Star Employer Health Plan. The governing criteria are Summit Specialty Review's Spine Surgery Guidelines: Cervical Fusion (SSR-CERV-2026.1), and this letter quotes and addresses those criteria rather than Lone Star Employer Health Plan's own medical policy.

This request is for anterior cervical discectomy and fusion at C5-C6 and C6-C7, planned for 2026-09-22 in the inpatient hospital setting at Trinity Valley Medical Center.

Every criterion in that policy is addressed in the Criterion-by-Criterion Documentation section. Each supporting record is enclosed and cited by exhibit, so the request can be decided on the documents submitted.

## 2. Clinical Summary

Mr. Whitfield is a 57-year-old man with cervical disc disease with progressive myelopathy at C5-C6 and C6-C7, first documented on 2026-06-10. He presented with neck pain and right arm paresthesias, then developed bilateral hand clumsiness and gait unsteadiness over ten weeks.

**Functional impact.** He can no longer button shirts or type reliably, has fallen twice, and has been placed on leave from his job as an electrician.

| ICD-10-CM | Description |
|---|---|
| M50.020 | Cervical disc disorder with myelopathy, mid-cervical region, unspecified level (primary) |
| M50.123 | Cervical disc disorder at C6-C7 level with radiculopathy |

## 3. Cervical Fusion with Disc Removal Evidence

### Red-Flag Findings

| Finding | First documented | Objective basis | Source |
|---|---|---|---|
| Progressive cervical myelopathy | 2026-08-19 | mJOA decline from 15 to 12 over ten weeks; new gait instability; bilateral Hoffmann sign | Exhibit B |
| Intramedullary T2 cord signal change at C5-C6 | 2026-08-26 | MRI cervical spine | Exhibit C |

### Neurological Examination

The examination on 2026-08-19 (Exhibit B) documents objective signs of cervical myelopathy. Findings include bilateral upper-extremity hyperreflexia, bilateral Hoffmann signs, right triceps weakness, and right C7 sensory loss.

| Motor | Side | Grade (0–5) |
|---|---|---|
| Deltoid (C5) | Bilateral | 5 |
| Biceps (C5–C6) | Right | 4+ |
| Triceps (C7) | Right | 4 |
| Grip (C8) | Bilateral | 4 |

| Reflex | Side | Finding |
|---|---|---|
| Biceps | Bilateral | 3+ |
| Triceps | Bilateral | 3+ |
| Hoffmann | Bilateral | Positive |

| Sensory distribution | Side | Finding |
|---|---|---|
| C7 dermatome | Right | Diminished to light touch and pinprick |

| Provocative test | Side | Result |
|---|---|---|
| Spurling | Right | Positive |

### Myelopathy Signs and Progression

| Sign | Side | First documented | Source |
|---|---|---|---|
| Hoffmann sign | Bilateral | 2026-08-19 | Exhibit B |
| Hyperreflexia (biceps, triceps) | Bilateral | 2026-08-19 | Exhibit B |
| Inability to perform tandem gait | — | 2026-08-19 | Exhibit B |

Examination on 2026-06-10 showed normal reflexes and gait. By 2026-08-19, bilateral Hoffmann signs, hyperreflexia, and gait instability had developed, with a three-point mJOA decline.

### Imaging and Clinical Concordance

| Study | Date | Level | Finding | Source |
|---|---|---|---|---|
| MRI cervical spine | 2026-08-26 | C5-C6 | Disc-osteophyte complex with severe central stenosis, cord flattening, and T2 intramedullary signal change | Exhibit C |
| MRI cervical spine | 2026-08-26 | C6-C7 | Moderate central stenosis with cord contact; right foraminal stenosis | Exhibit C |
| Flexion-extension radiographs | 2026-08-19 | C3-T1 | No dynamic instability | Exhibit D |

Each treated level correlates with the examination and the patient's symptom distribution:

| Level | Imaging finding | Examination finding | Symptom correlation |
|---|---|---|---|
| C5-C6 | Severe stenosis, cord signal change | Hoffmann signs, hyperreflexia, gait instability | Bilateral hand clumsiness, falls |
| C6-C7 | Cord contact, right foraminal stenosis | Right triceps 4/5, right C7 sensory loss | Right arm paresthesias into the middle finger |

The most recent advanced imaging (MRI cervical spine, 2026-08-26) was obtained less than one month before the anticipated date of service, within the policy's 6-month window.

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| mJOA | 2026-06-10 | 15/18 | Mild myelopathy | Exhibit A |
| mJOA | 2026-08-19 | 12/18 | Moderate myelopathy | Exhibit B |
| Neck Disability Index | 2026-08-19 | 24/50 (48%) | Moderate disability | Exhibit B |

The mJOA decline of three points in ten weeks is objective evidence of neurological progression.

### Conservative Care

The policy waives the conservative care requirement when red-flag findings are present. This patient has progressive cervical myelopathy and intramedullary T2 cord signal change at C5-C6, documented under Red-Flag Findings. The treatment completed before surgery became indicated is listed for completeness.

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2026-07-22 to 2026-08-19 | 8 sessions, twice weekly | Stopped when myelopathic signs developed | Exhibit E |
| Naproxen and gabapentin | 2026-07-20 to 2026-08-26 | Naproxen 500 mg twice daily; gabapentin 300 mg three times daily | Minimal relief of arm pain; no effect on hand function | Exhibit E |

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| Nicotine | Never | 2026-08-19 | Nicotine-free ≥ 6 weeks | Exhibit B |
| BMI | 29.4 kg/m² | 2026-08-19 | ≤ 40 | Exhibit B |

### Level Selection

2 levels requested: C5-C6, C6-C7. This is within the policy limit of 3 levels per procedure.

| Level | Rationale | Source |
|---|---|---|
| C5-C6 | Severe central stenosis with cord flattening and T2 signal change; concordant with myelopathic signs. | Exhibit C |
| C6-C7 | Moderate central stenosis with cord contact and right foraminal stenosis; concordant with right C7 deficit. | Exhibit C |

**Adjacent levels not included**

- **C4-C5:** Mild disc desiccation without stenosis or cord contact, and no correlating examination findings.

### Instrumentation, Devices, and Graft

| Code | Description | Units | Clinical justification |
|---|---|---|---|
| 22845 | Anterior instrumentation, 2 to 3 vertebral segments | 1 | Anterior plate fixation across C5–C7 provides immediate stability for a two-level construct and reduces pseudarthrosis risk. |
| 22853 | Insertion of interbody biomechanical device, each interspace | 2 | Interbody cages at each interspace restore disc height and foraminal dimensions. |
| 20930 | Allograft, morselized, for spine surgery | 1 | Morselized allograft within the cages promotes arthrodesis without a separate harvest incision. |

### Site of Service

Inpatient admission is requested. Postoperative neurological monitoring is required given progressive myelopathy with intramedullary cord signal change.

- Progressive myelopathy with T2 cord signal change carries a risk of postoperative neurological change that needs serial examinations.
- A two-level anterior construct carries a risk of dysphagia and airway edema in the first 24 hours.
- Gait instability before surgery requires inpatient physical therapy assessment before discharge.

## 4. Criterion-by-Criterion Documentation

Each criterion below is quoted from Spine Surgery Guidelines: Cervical Fusion (SSR-CERV-2026.1).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| 1 | Imaging demonstrates cord or root compression concordant with clinical findings | Met | MRI 2026-08-26: C5-C6 cord signal change; C6-C7 cord contact and right foraminal stenosis | Exhibit C |
| 2 | At least 6 weeks of conservative care, unless progressive neurological deficit or myelopathy is present | Not applicable | Progressive myelopathy documented; the guideline exception applies | Exhibit B |
| 3 | Objective neurological findings on examination | Met | Hoffmann signs, hyperreflexia, right triceps 4/5, right C7 sensory loss | Exhibit B |
| 4 | Nicotine-free status | Met | Lifelong non-smoker | Exhibit B |
| 5 | Advanced imaging within 6 months | Met | MRI dated 2026-08-26 | Exhibit C |

## 5. Medical Necessity

Decompression and fusion at C5-C6 and C6-C7 is the standard treatment for progressive degenerative cervical myelopathy with cord signal change. The goal is to halt neurological decline, which is often irreversible once established.

**Alternatives considered.** Continued nonoperative care is inappropriate with progressive myelopathy. A posterior approach is less suitable because the compression is anterior (disc-osteophyte complex) and the cervical lordosis is preserved.

**Consequences of delay or denial.** Further myelopathic progression, falls with risk of spinal cord injury, and permanent loss of hand function and gait.

## 6. Submission Notes

- This is a pre-service claim under the plan's claims procedures governed by 29 C.F.R. § 2560.503-1. Because this request is urgent, a decision is requested within 72 hours.
- Please send the determination to this office and to Trinity Valley Medical Center.
- If this request cannot be approved as submitted, please arrange a peer-to-peer discussion with a clinician in orthopedic spine surgery or a closely related specialty before an adverse determination is issued.

## 7. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 22551 | — | Anterior interbody arthrodesis with discectomy and decompression, cervical below C2, single interspace | 1 |
| 22552 | — | Anterior interbody arthrodesis, cervical below C2, each additional interspace | 1 |
| 22845 | — | Anterior instrumentation, 2 to 3 vertebral segments | 1 |
| 22853 | — | Insertion of interbody biomechanical device, each interspace | 2 |
| 20930 | — | Allograft, morselized, for spine surgery | 1 |

Site of service: Inpatient hospital, Trinity Valley Medical Center. Anticipated date of service: 2026-09-22.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this request may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Adaeze Okafor, MD**\
Orthopedic Spine Surgery · NPI 1528000025

*Electronically affirmed by Adaeze Okafor, MD on 2026-09-10 08:05 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Initial consultation with mJOA | 2026-06-10 | 3 |
| B | Follow-up examination with mJOA and NDI | 2026-08-19 | 4 |
| C | MRI cervical spine report | 2026-08-26 | 2 |
| D | Flexion-extension radiograph report | 2026-08-19 | 1 |
| E | Physical therapy notes and medication record | 2026-07-20 to 2026-08-26 | 6 |

cc: Daniel R. Whitfield
