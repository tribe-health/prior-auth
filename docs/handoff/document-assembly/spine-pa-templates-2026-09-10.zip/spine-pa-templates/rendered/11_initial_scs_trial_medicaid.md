![Advanced Spine & Orthopedics](assets/aso-logo.svg)

**Advanced Spine & Orthopedics**\
261 W Southlake Blvd, Southlake, TX 76092\
Phone (817) 555-0142 · Fax (817) 555-0143 · NPI [practice group NPI]

September 10, 2026

Sent via fax to:\
Gulf Coast Community Health Plan — Utilization Management — Prior Authorization\
PO Box 0000, Example City, TX 77000\
Fax (800) 555-0155

**RE: Prior Authorization Request — Texas Medicaid**

| Field | Value |
|---|---|
| Member | Teresa M. Villarreal |
| Date of birth | 1979-03-08 |
| Member ID | TXM-0048812205 |
| Requested service | Spinal cord stimulator trial with two percutaneous epidural leads |
| Codes | 63650 ×2 |
| Diagnoses | M96.1, M54.17 |
| Site of service | Hospital outpatient department |
| Requesting physician | Jordan Reyes, MD · NPI 1497000011 |
| Facility | Trinity Valley Medical Center · NPI 1740000049 |
| Anticipated date of service | 2026-09-29 |

Dear Utilization Management Reviewer,

I am requesting prior authorization of spinal cord stimulator trial with two percutaneous epidural leads for my patient, Teresa M. Villarreal, who is enrolled with Gulf Coast Community Health Plan. The service is medically necessary and meets each applicable criterion of Spinal Cord Stimulation Clinical Policy (GCC-CP-122), as documented below.

## 1. Request Summary

This request is for spinal cord stimulator trial with two percutaneous epidural leads, planned for 2026-09-29 in the hospital outpatient department setting at Trinity Valley Medical Center. It is governed by Spinal Cord Stimulation Clinical Policy (GCC-CP-122, sample, effective 2026-01-01).

Every criterion in that policy is addressed in the Criterion-by-Criterion Documentation section. Each supporting record is enclosed and cited by exhibit, so the request can be decided on the documents submitted.

## 2. Clinical Summary

Ms. Villarreal is a 47-year-old woman with persistent left S1 radicular pain after L5-S1 fusion (postlaminectomy syndrome), first documented on 2023-10-12. Since her 2023 L5-S1 fusion, she has had constant burning pain in the left leg in an S1 distribution.

**Functional impact.** She cannot sit longer than 20 minutes, cannot work, and relies on family for childcare.

| ICD-10-CM | Description |
|---|---|
| M96.1 | Postlaminectomy syndrome, not elsewhere classified (primary) |
| M54.17 | Radiculopathy, lumbosacral region |

## 3. Implanted Spinal Neurostimulator Evidence

### Neurostimulation Indication

Neuropathic radicular pain persisting more than two years after a solidly fused L5-S1 arthrodesis, with no recurrent compression on imaging.

**Surgical options.** Her surgeon's evaluation on 2026-03-04 found a solid fusion without hardware failure or recurrent stenosis, so further surgery is not indicated.

**Contraindications screened.** She has no coagulopathy, active infection, or untreated substance use disorder, and she is able to operate the device.

### Validated Outcome Measures

| Instrument | Date | Score | Interpretation | Source |
|---|---|---|---|---|
| NRS pain | 2026-06-30 | 8/10 | Severe pain | Exhibit A |
| Oswestry Disability Index | 2026-06-30 | 56% | Severe disability | Exhibit A |

### Conservative Care

| Modality | Dates | Frequency / dose | Response | Source |
|---|---|---|---|---|
| Physical therapy | 2024-02-05 to 2024-05-24 | 24 sessions | No durable benefit | Exhibit B |
| Gabapentinoids and duloxetine | 2023-12-01 to 2026-06-30 | Pregabalin 150 mg twice daily; duloxetine 60 mg daily | Partial relief; sedation limits dosing | Exhibit B |
| Cognitive behavioral therapy for pain | 2025-01-10 to 2025-04-11 | 12 sessions | Improved coping; pain unchanged | Exhibit B |

Documented conservative care spans 134 weeks (2023-12-01 to 2026-06-30), meeting the policy minimum of 26 weeks, and includes physical therapy, medication management, and behavioral therapy. Symptoms persisted despite this treatment.

### Psychological Evaluation

A licensed clinical psychologist completed a psychological evaluation on 2026-05-20 (Exhibit D) and cleared the patient for neurostimulation. The evaluation found no untreated major depression, psychosis, or substance use disorder, and realistic expectations for outcome.

### Modifiable Risk Factors

| Factor | Finding | Date | Policy threshold | Source |
|---|---|---|---|---|
| BMI | 27.8 kg/m² | 2026-06-30 | — | Exhibit A |

### Site of Service

The procedure is planned in the hospital outpatient department setting at Trinity Valley Medical Center.

## 4. Criterion-by-Criterion Documentation

Each criterion below is quoted from Spinal Cord Stimulation Clinical Policy (GCC-CP-122).

| # | Criterion | Status | Supporting documentation | Source |
|---|---|---|---|---|
| 1 | Chronic neuropathic pain for at least 6 months with failure of conservative therapy | Met | Pain since 2023; PT, pharmacotherapy, and CBT | Exhibit B |
| 2 | Further surgical intervention is not indicated | Met | Surgical evaluation 2026-03-04: solid fusion, no recurrent compression | Exhibit C |
| 3 | Psychological evaluation clearing the member for implantation | Met | Evaluation 2026-05-20, cleared | Exhibit D |
| 4 | A temporary trial precedes any permanent implantation | Met | This request is for the trial; permanent implantation will be requested only after a successful trial | — |

## 5. Medical Necessity

A temporary stimulator trial is the required first step toward neurostimulation for persistent neuropathic radicular pain after spinal fusion when further surgery is not indicated. It tests response before any permanent implant.

**Alternatives considered.** Revision surgery is not indicated. Escalating pharmacotherapy is limited by sedation, and she wants to avoid long-term opioids.

**Consequences of delay or denial.** Continued disability, and escalating pharmacotherapy that sedation already limits.

## 6. Submission Notes

- Please issue the decision within the Medicaid managed care timeframe that applies under CMS-0057-F: 7 calendar days for a standard request. Please send written notice to the member and to this office.
- If this request cannot be approved as submitted, please arrange a peer-to-peer discussion with a clinician in interventional spine and pain medicine or a closely related specialty before an adverse determination is issued.

## 7. Requested Action

Please authorize the following services:

| Code | Modifiers | Description | Units |
|---|---|---|---|
| 63650 | — | Percutaneous implantation of neurostimulator electrode array, epidural | 2 |

Site of service: Hospital outpatient department, Trinity Valley Medical Center. Anticipated date of service: 2026-09-29.

I am available for a peer-to-peer discussion at (817) 555-0144 (weekdays 7:00–9:00 a.m. and 12:00–1:00 p.m. Central). Questions about this request may be directed to Prior Authorization Coordinator at (817) 555-0145 or priorauth@example-spine.test.

Thank you for your prompt review.

Sincerely,

**Jordan Reyes, MD**\
Interventional Spine and Pain Medicine · NPI 1497000011

*Electronically affirmed by Jordan Reyes, MD on 2026-09-10 11:40 CT. I attest that the information in this letter is accurate and supported by the enclosed medical records.*

**Enclosures**

| Exhibit | Document | Date | Pages |
|---|---|---|---|
| A | Office note with NRS and ODI | 2026-06-30 | 3 |
| B | Conservative treatment records | 2023-12-01 to 2026-06-30 | 16 |
| C | Surgical evaluation and imaging | 2026-03-04 | 4 |
| D | Psychological evaluation report | 2026-05-20 | 5 |

cc: Teresa M. Villarreal
