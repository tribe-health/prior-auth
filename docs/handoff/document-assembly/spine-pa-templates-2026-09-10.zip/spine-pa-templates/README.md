# Spine & Orthopedic Prior Authorization Response Templates

A multi-part MiniJinja template system for Advanced Spine & Orthopedics that renders two kinds of payer-facing prior authorization letters for spine and orthopedic procedures: the **initial request** and the **denial response**. Rust makes every decision the templates depend on.

```
case.json ──► enrich (classify · derive · gate) ──► MiniJinja ──► letter.md (initial_request | denial_response)
                         │
                         └── any gate item ──► halt memo (internal, never sent)
```

**Design rule: templates render, Rust decides.** Code classification, date arithmetic, threshold comparison, and exhibit integrity are computed once in `src/enrich.rs`. Templates branch only on those precomputed values, so the letter and the halt memo can never disagree about a case.

**Fail-closed.** Any `void` or `open_gap` item replaces the letter with an internal memo. An unaffirmed letter renders with a draft banner and no signature. Unknown codes, statuses, programs, or response patterns are hard errors rather than guesses.

## Run

```sh
cargo test                                          # 15 tests: fixtures, gates, letter kinds, fail-closed paths
cargo run -- render fixtures/01_facet_rfa_medicare_ffs.json
cargo run -- context fixtures/02_acdf_commercial_benefit_manager.json   # enriched context JSON
cargo run -- render-all fixtures rendered
```

## Layout

```
catalog/cpt_catalog.json         Code → family/category/region/subtype; family precedence; payer void rules
src/catalog.rs                   Catalog loading and family classification
src/enrich.rs                    Derived facts and pre-send gates
src/main.rs                      Renderer, CLI, tests
templates/
  letter.md.j2                   Entry point: halt memo or letter kind
  kinds/                         initial_request, denial_response (structure and numbering)
  macros/format.md.j2            status_label, exhibit, code_list, site_label, series, plural
  gate/                          halt_memo, draft_banner
  core/                          Sections common to every letter (13 partials)
  routing/                       Denial-response vocabulary per program + benefit manager overlay
  routing/initial/               Initial-request vocabulary per program (same six macros)
  denial_patterns/               One partial per response pattern
  clinical/                      Shared specialty evidence partials (9)
  procedures/<family>.md.j2      Evidence composition per procedure family
  procedures/<family>/           Family-specific partials
assets/aso-logo.svg              Practice lockup, referenced by practice.logo in the letterhead
fixtures/                        Twelve synthetic cases: 7 denial responses, 5 initial requests
rendered/                        Output for each fixture
```

## Selection Axes

| Axis | Values | Selects | Where it is decided |
|---|---|---|---|
| `gate.halt` | true / false | `gate/halt_memo.md.j2` replaces the letter | `enrich.rs` |
| `letter.kind` | `initial_request`, `denial_response` | `kinds/<kind>.md.j2`; initial requests import `routing/initial/<program>.md.j2` | case data, validated in Rust |
| `payer.program` | `medicare_ffs_opd`, `medicare_advantage`, `commercial`, `medicaid` | `routing/<program>.md.j2` macros: RE label, salutation, opening, rights, action verb, submission noun | case data, validated in Rust |
| `payer.benefit_manager` | object or absent | Addressee swap in `core/header` and the `_benefit_manager` overlay | case data |
| `payer.erisa`, `state_regulation`, `internal_criteria_used` | flags | Rights language inside the routing module | case data |
| `procedure.family` | 6 families | `procedures/<family>.md.j2`, falling back to `_generic` | catalog, by precedence |
| `procedure.subtype` | `rfa` / `diagnostic_block`; `trial` / `permanent` | Branches inside the facet and SCS modules | catalog |
| `derived.red_flag_bypass` | true / false | Waives conservative care; reorders the cervical module to lead with red flags | `enrich.rs` |
| `denial_reasons[].pattern` | `overlooked`, `newly_supplied`, `not_applicable`, `misapplied`, `clinical_exception` | `denial_patterns/<pattern>.md.j2` | case data, validated in Rust |
| `affirmation.affirmed` | true / false | Signature block vs. withheld block and draft banner | case data |

## Letter Kinds

| | Initial request | Denial response |
|---|---|---|
| Kind template | `kinds/initial_request.md.j2` | `kinds/denial_response.md.j2` |
| Routing | `routing/initial/<program>.md.j2` | `routing/<program>.md.j2` |
| Opening section | Request Summary | Determination Being Addressed |
| Reason-by-reason answers | — | `denial_patterns/<pattern>.md.j2` |
| Closing notes | Submission Notes: decision timeframes, UTN handling, peer-to-peer before denial | Procedural Requests: criteria copies, reviewer specialty, appeal rights |
| Criteria statuses allowed | `MET`, `NOT_APPLICABLE`, `GAP`, `VOID` | all six |
| `denial_reasons` | must be empty | at least one |
| Shared | header, RE block, clinical summary, every procedure module and clinical partial, criteria table, necessity, literature, requested action, signature, enclosures | same |

Both kinds pass through the same gates. For an initial request that is the point: a request that would be denied for missing documentation halts before it is sent (fixture 12).

## Composition by Procedure Family

| Partial | Facet | Cervical fusion | Lumbar fusion | Lumbar decompression | SCS | Joint arthroplasty |
|---|---|---|---|---|---|---|
| `clinical/outcome_scores` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| `clinical/conservative_care` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| `clinical/neuro_exam` (purpose) | exclusion | myelopathy or deficit | deficit | deficit | baseline, if present | — |
| `clinical/imaging_concordance` | if present | ✓ | ✓ | ✓ | — | — |
| `clinical/red_flags` | — | ✓ (leads on bypass) | — | ✓ | — | — |
| `clinical/risk_factors` | — | ✓ | ✓ | — | ✓ | ✓ |
| `clinical/level_justification` | ✓ | ✓ | ✓ | ✓ | — | — |
| `clinical/instrumentation` | — | ✓ | ✓ | — | — | — |
| `clinical/site_of_service` | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| Family-specific | `diagnostic_blocks` (RFA), `prior_rfa` (repeat), `frequency` | `myelopathy` | `fusion_indication` | `claudication` | `indication`, `psych_eval`, `trial_results` (permanent) | `joint_status` |

Families and codes:

| Family | Codes |
|---|---|
| Facet joint intervention | 64490–64495, 64633–64636 |
| Cervical fusion with disc removal | 22551, 22552 |
| Lumbar fusion | 22612/22614, 22630/22632, 22633/22634 |
| Lumbar decompression | 63030/63035, 63047/63048 |
| Implanted spinal neurostimulator | 63650, 63655, 63685, 63688 |
| Total joint arthroplasty | 27447, 27130 |
| Adjunct (attaches to the governing family) | 22840, 22842, 22845, 22853, 20930, 20931, 20936 |

When a request spans families, `family_precedence` decides. Decompression billed with fusion renders as fusion.

## Gates

| Check | Kind | Trigger |
|---|---|---|
| Criterion status | void / open_gap | `criteria[].status` is `VOID` or `GAP` |
| Code void rule | void | Catalog `void_rules` match the program (64492/64495 under Medicare FFS OPD) |
| Level limit | void | `procedure.levels` exceeds `policy.max_levels` |
| Conservative duration | open_gap | Span below `policy.min_conservative_weeks` with no red-flag bypass |
| Required modalities | open_gap | A `policy.required_modalities` category is missing, with no bypass |
| Imaging recency | open_gap | No advanced imaging, no date of service, or imaging older than `policy.max_imaging_age_months` |
| BMI / HbA1c | open_gap | Value exceeds `policy.max_bmi` / `policy.max_hba1c` |
| Nicotine | open_gap | Current use; former use under `nicotine_free_weeks` at the date of service; unverified when verification is required |
| Facet diagnostic blocks | open_gap | RFA with fewer than `required_blocks` at or above `min_block_relief_pct` |
| Facet repeat RFA | open_gap | Prior ablation below `min_repeat_relief_pct` or `min_repeat_relief_months` |
| Facet frequency | void | Request would exceed `max_sessions_12mo` |
| SCS psychological evaluation | open_gap | `clinical.psych_eval.cleared` is not true |
| SCS trial | open_gap | Permanent implant without a trial at or above `min_trial_relief_pct` |
| Denial response evidence | open_gap | `overlooked` or `newly_supplied` without an exhibit; `misapplied` without a verbatim policy quote |
| Exhibit integrity | open_gap | Any `exhibit` or `*_exhibit` value anywhere in the case is missing from `exhibits` |

Unverified literature (`references[].verified != true`) is removed from the letter and listed as a warning in the draft banner.

## Context Contract

Supplied by the case record: `letter`, `practice`, `payer`, `policy`, `patient` (with `short_name` for mid-sentence use), `providers.requesting`, `providers.facility`, `procedure` (with `services`, `levels`, `site_of_service`, `anticipated_dos`), `diagnoses`, `clinical`, `criteria`, `denial_reasons`, `necessity`, `references`, `procedural`, `expedited`, `p2p`, `contact`, `exhibits`, `affirmation`.

Added by Rust:

| Key | Content |
|---|---|
| `procedure.family`, `family_label`, `subtype`, `region`, `level_count` | Classification |
| `procedure.description_inline`, `clinical.red_flags[].flag_inline` | Acronym-safe mid-sentence forms |
| `procedure.services[].category`, `is_addon`, `description` | Catalog data per code |
| `providers.signing` | Defaults to `providers.requesting` |
| `derived.conservative_start`, `conservative_end`, `conservative_span_weeks`, `modalities_completed` | Conservative care summary |
| `derived.red_flag_bypass`, `latest_advanced_imaging`, `qualifying_blocks`, `gap_closed_ids`, `warnings` | Derived facts |
| `gate.halt`, `items`, `void_count`, `gap_count` | Gate result |

Policy thresholds live in `policy`, per case. In production they come from a policy registry keyed by payer, program, and procedure family, never from the model.

## Extending

**New payer program.** Add `templates/routing/<program>.md.j2` and `templates/routing/initial/<program>.md.j2`, each exposing `re_label`, `salutation`, `opening`, `rights`, `action_verb`, and `submission_noun`, then add the name to `PROGRAMS` in `enrich.rs`.

**New procedure family.** Add codes to the catalog with the new `family`, add it to `family_precedence` and `family_labels`, and create `procedures/<family>.md.j2` composed from the `clinical/` partials plus any family-specific partials. Add family gates to the `match` in `enrich.rs`.

**New payer-specific code rule.** Add a `void_rules` entry to the catalog. No template or code change is needed.

**New response pattern.** Add `denial_patterns/<pattern>.md.j2` and the name to `PATTERNS`, with any evidence requirement in `check_denial_reasons`.

**New letter kind.** Add `templates/kinds/<kind>.md.j2` and the name to `KINDS` in `enrich.rs`, with any kind-specific validation beside the existing checks.

## Whitespace Conventions

The environment uses `trim_blocks`, `lstrip_blocks`, `keep_trailing_newline`, and `UndefinedBehavior::SemiStrict` (a missing value may be tested but never printed). A block tag that ends a line of content is written `{% endif +%}` so the line keeps its newline. Markdown tables depend on this.

## Verify Before Production Use

- **Fixtures are synthetic.** Criteria text is paraphrased and thresholds are illustrative. Replace both with verbatim language and values from the governing policy.
- The Medicare fixture cites LCD L38803 as the Jurisdiction H facet LCD. Confirm the number and current revision in the Medicare Coverage Database.
- CPT descriptors in the catalog are abbreviated. Confirm them against the current codebook.
- Have counsel review the regulatory citations in the routing modules (29 C.F.R. § 2560.503-1, 42 C.F.R. § 422.101(b)(6), CMS-0057-F decision timeframes, and the Texas Insurance Code reference) before use.
- The letterhead's phone, fax, and NPI are placeholders. The logo is the brand guide's working reconstruction; replace it with the original artwork when recovered.
