//! Render spine and orthopedic prior authorization responses from case JSON.
//!
//! Pipeline: case JSON → enrich (classify, derive, gate) → MiniJinja → Markdown.
//! A case that fails any gate renders an internal halt memo, never a letter.

mod catalog;
mod enrich;

use minijinja::{Environment, UndefinedBehavior, path_loader};
use serde_json::Value;
use std::error::Error;
use std::path::{Path, PathBuf};
use std::process::ExitCode;
use std::{env, fs};

const MANIFEST_DIR: &str = env!("CARGO_MANIFEST_DIR");
const ROOT_TEMPLATE: &str = "letter.md.j2";

pub struct Renderer {
    env: Environment<'static>,
    catalog: catalog::Catalog,
}

impl Renderer {
    pub fn new(base: &Path) -> Result<Self, Box<dyn Error>> {
        let mut env = Environment::new();
        env.set_loader(path_loader(base.join("templates")));
        // SemiStrict: `{% if missing %}` is allowed; printing a missing value is an error.
        env.set_undefined_behavior(UndefinedBehavior::SemiStrict);
        env.set_trim_blocks(true);
        env.set_lstrip_blocks(true);
        // Partials end with a newline so the orchestrator's blank lines separate sections.
        env.set_keep_trailing_newline(true);
        let catalog = catalog::Catalog::load(&base.join("catalog/cpt_catalog.json"))?;
        Ok(Self { env, catalog })
    }

    pub fn enrich(&self, raw: &str) -> Result<Value, Box<dyn Error>> {
        let mut case: Value = serde_json::from_str(raw)?;
        enrich::enrich(&mut case, &self.catalog)?;
        Ok(case)
    }

    pub fn render(&self, raw: &str) -> Result<String, Box<dyn Error>> {
        let case = self.enrich(raw)?;
        let out = self.env.get_template(ROOT_TEMPLATE)?.render(&case)?;
        Ok(normalize(&out))
    }
}

/// Collapse runs of blank lines and strip trailing whitespace so Markdown tables stay intact.
fn normalize(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut blank_run = 0;
    for line in s.lines().map(str::trim_end) {
        if line.is_empty() {
            blank_run += 1;
            if blank_run > 1 {
                continue;
            }
        } else {
            blank_run = 0;
        }
        out.push_str(line);
        out.push('\n');
    }
    format!("{}\n", out.trim())
}

fn fixtures_in(dir: &Path) -> Result<Vec<PathBuf>, Box<dyn Error>> {
    let mut paths: Vec<PathBuf> = fs::read_dir(dir)?
        .filter_map(Result::ok)
        .map(|e| e.path())
        .filter(|p| p.extension().is_some_and(|x| x == "json"))
        .collect();
    paths.sort();
    Ok(paths)
}

fn run(args: &[String]) -> Result<(), Box<dyn Error>> {
    let renderer = Renderer::new(Path::new(MANIFEST_DIR))?;
    match args {
        [cmd, case] if cmd == "render" => {
            print!("{}", renderer.render(&fs::read_to_string(case)?)?);
        }
        [cmd, case] if cmd == "context" => {
            let ctx = renderer.enrich(&fs::read_to_string(case)?)?;
            println!("{}", serde_json::to_string_pretty(&ctx)?);
        }
        [cmd, dir, out] if cmd == "render-all" => {
            fs::create_dir_all(out)?;
            for path in fixtures_in(Path::new(dir))? {
                let target =
                    Path::new(out).join(path.with_extension("md").file_name().ok_or("bad path")?);
                let rendered = renderer
                    .render(&fs::read_to_string(&path)?)
                    .map_err(|e| format!("{}: {e:#}", path.display()))?;
                fs::write(&target, rendered)?;
                println!("rendered {} → {}", path.display(), target.display());
            }
        }
        _ => {
            return Err("usage:\n  spine-pa-templates render <case.json>\n  spine-pa-templates context <case.json>\n  spine-pa-templates render-all <fixtures_dir> <out_dir>".into());
        }
    }
    Ok(())
}

fn main() -> ExitCode {
    let args: Vec<String> = env::args().skip(1).collect();
    match run(&args) {
        Ok(()) => ExitCode::SUCCESS,
        Err(e) => {
            eprintln!("error: {e:#}");
            ExitCode::FAILURE
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn renderer() -> Renderer {
        Renderer::new(Path::new(MANIFEST_DIR)).expect("renderer")
    }

    fn fixture(name: &str) -> String {
        fs::read_to_string(Path::new(MANIFEST_DIR).join("fixtures").join(name)).expect("fixture")
    }

    #[test]
    fn every_fixture_renders_without_template_residue() {
        let r = renderer();
        for path in fixtures_in(&Path::new(MANIFEST_DIR).join("fixtures")).unwrap() {
            let out = r
                .render(&fs::read_to_string(&path).unwrap())
                .unwrap_or_else(|e| panic!("{}: {e:#}", path.display()));
            assert!(
                !out.contains("{{") && !out.contains("{%"),
                "{} leaked template syntax",
                path.display()
            );
        }
    }

    #[test]
    fn void_case_renders_halt_memo_not_letter() {
        let out = renderer()
            .render(&fixture("07_facet_void_three_level.json"))
            .unwrap();
        assert!(out.contains("Letter Generation Halted"));
        assert!(!out.contains("Dear "));
    }

    #[test]
    fn passing_cases_render_letters() {
        let r = renderer();
        for name in [
            "01_facet_rfa_medicare_ffs.json",
            "02_acdf_commercial_benefit_manager.json",
            "03_lumbar_fusion_medicare_advantage.json",
            "04_lumbar_decompression_commercial.json",
            "05_scs_permanent_medicaid.json",
            "06_tka_commercial_asc.json",
            "08_initial_facet_rfa_medicare_ffs.json",
            "09_initial_acdf_commercial_benefit_manager.json",
            "10_initial_lumbar_fusion_medicare_advantage.json",
            "11_initial_scs_trial_medicaid.json",
        ] {
            let out = r.render(&fixture(name)).unwrap();
            assert!(out.contains("Dear "), "{name} did not render a letter");
        }
    }

    #[test]
    fn unaffirmed_letter_withholds_signature() {
        let out = renderer()
            .render(&fixture("02_acdf_commercial_benefit_manager.json"))
            .unwrap();
        assert!(out.contains("PENDING PHYSICIAN AFFIRMATION"));
        assert!(out.contains("Signature withheld"));
        assert!(!out.contains("Electronically affirmed"));
    }

    #[test]
    fn open_gap_halts_an_otherwise_valid_case() {
        let mut case: Value =
            serde_json::from_str(&fixture("01_facet_rfa_medicare_ffs.json")).unwrap();
        case["criteria"][0]["status"] = "GAP".into();
        let out = renderer().render(&case.to_string()).unwrap();
        assert!(out.contains("Letter Generation Halted"));
    }

    #[test]
    fn unknown_code_fails_closed() {
        let mut case: Value =
            serde_json::from_str(&fixture("01_facet_rfa_medicare_ffs.json")).unwrap();
        case["procedure"]["services"][0]["code"] = "99999".into();
        assert!(renderer().render(&case.to_string()).is_err());
    }

    #[test]
    fn dangling_exhibit_reference_halts() {
        let mut case: Value =
            serde_json::from_str(&fixture("01_facet_rfa_medicare_ffs.json")).unwrap();
        case["denial_reasons"][0]["exhibit"] = "Z".into();
        let out = renderer().render(&case.to_string()).unwrap();
        assert!(out.contains("Exhibit Z is cited but not listed"));
    }

    #[test]
    fn initial_request_renders_as_request_not_response() {
        let r = renderer();
        for name in [
            "08_initial_facet_rfa_medicare_ffs.json",
            "09_initial_acdf_commercial_benefit_manager.json",
            "10_initial_lumbar_fusion_medicare_advantage.json",
            "11_initial_scs_trial_medicaid.json",
        ] {
            let out = r.render(&fixture(name)).unwrap();
            assert!(out.contains("Request Summary"), "{name}: no request summary");
            assert!(out.contains("Submission Notes"), "{name}: no submission notes");
            assert!(!out.contains("Response to Denial Reasons"), "{name}: rendered denial section");
            assert!(!out.contains("Determination Being Addressed"), "{name}: rendered determination section");
            assert!(!out.contains("Determination date"), "{name}: rendered determination row");
        }
    }

    #[test]
    fn scs_request_without_generator_is_a_trial() {
        let ctx = renderer().enrich(&fixture("11_initial_scs_trial_medicaid.json")).unwrap();
        assert_eq!(ctx["procedure"]["subtype"], "trial");
        let out = renderer().render(&fixture("11_initial_scs_trial_medicaid.json")).unwrap();
        assert!(!out.contains("Trial Results"));
    }

    #[test]
    fn gated_initial_request_halts_before_submission() {
        let out = renderer().render(&fixture("12_initial_tka_commercial_halt.json")).unwrap();
        assert!(out.contains("Letter Generation Halted"));
        assert!(out.contains("`initial_request`"));
        assert!(!out.contains("Dear "));
    }

    #[test]
    fn initial_request_rejects_denial_reasons() {
        let mut case: Value = serde_json::from_str(&fixture("08_initial_facet_rfa_medicare_ffs.json")).unwrap();
        case["denial_reasons"] = serde_json::json!([{ "pattern": "overlooked", "verbatim": "x", "response": "y", "exhibit": "A" }]);
        let err = renderer().render(&case.to_string()).unwrap_err().to_string();
        assert!(err.contains("must be empty for an initial_request"), "{err}");
    }

    #[test]
    fn initial_request_rejects_determination_statuses() {
        let mut case: Value = serde_json::from_str(&fixture("08_initial_facet_rfa_medicare_ffs.json")).unwrap();
        case["criteria"][0]["status"] = "GAP_CLOSED".into();
        let err = renderer().render(&case.to_string()).unwrap_err().to_string();
        assert!(err.contains("describes a prior determination"), "{err}");
    }

    #[test]
    fn letter_kind_is_required() {
        let mut case: Value = serde_json::from_str(&fixture("01_facet_rfa_medicare_ffs.json")).unwrap();
        case["letter"].as_object_mut().unwrap().remove("kind");
        assert!(renderer().render(&case.to_string()).is_err());
        case["letter"]["kind"] = "appeal".into();
        assert!(renderer().render(&case.to_string()).is_err());
    }

    /// With trim_blocks, a block tag that ends a line of content swallows the newline,
    /// merging paragraphs or table rows. Such lines must end in `+%}` instead.
    #[test]
    fn content_lines_never_end_in_an_unguarded_block_tag() {
        fn walk(dir: &Path, out: &mut Vec<PathBuf>) {
            for e in fs::read_dir(dir).unwrap().filter_map(Result::ok) {
                let p = e.path();
                if p.is_dir() { walk(&p, out) } else if p.extension().is_some_and(|x| x == "j2") { out.push(p) }
            }
        }
        let mut files = Vec::new();
        walk(&Path::new(MANIFEST_DIR).join("templates"), &mut files);
        let mut offenders = Vec::new();
        for f in files {
            for (i, line) in fs::read_to_string(&f).unwrap().lines().enumerate() {
                let t = line.trim();
                let is_tag_only = t.starts_with("{%") || t.starts_with("{#") || t.starts_with("} %}");
                if !is_tag_only && t.ends_with("%}") && !t.ends_with("+%}") && !t.ends_with("-%}") {
                    offenders.push(format!("{}:{}", f.display(), i + 1));
                }
            }
        }
        assert!(offenders.is_empty(), "content lines ending in a block tag: {offenders:?}");
    }

    #[test]
    fn request_summary_keeps_its_paragraphs() {
        let out = renderer().render(&fixture("10_initial_lumbar_fusion_medicare_advantage.json")).unwrap();
        assert!(out.contains(").\n\nEvery criterion in that policy"), "request summary paragraphs merged");
    }
}
