//! CPT/HCPCS classification catalog.
//!
//! The catalog is data (`catalog/cpt_catalog.json`), not code, so adding a
//! procedure family or a payer void rule never requires a template change.
//! Unknown codes are a hard error: the system refuses to guess a family.

use serde::Deserialize;
use std::collections::HashMap;
use std::error::Error;
use std::path::Path;

#[derive(Debug, Deserialize)]
pub struct Catalog {
    /// Highest precedence first. When a request spans families (for example,
    /// decompression billed with fusion), the first match governs the letter.
    pub family_precedence: Vec<String>,
    pub family_labels: HashMap<String, String>,
    pub codes: HashMap<String, CodeEntry>,
    pub void_rules: Vec<VoidRule>,
}

#[derive(Debug, Deserialize)]
pub struct CodeEntry {
    /// Procedure family, or `adjunct` for instrumentation, devices, and graft.
    pub family: String,
    /// `primary`, `addon_level`, `instrumentation`, `device`, `graft`, or `generator`.
    pub category: String,
    #[serde(default)]
    pub region: Option<String>,
    #[serde(default)]
    pub subtype: Option<String>,
    pub description: String,
}

/// A code that is non-covered for a program regardless of documentation.
#[derive(Debug, Deserialize)]
pub struct VoidRule {
    pub codes: Vec<String>,
    pub programs: Vec<String>,
    pub reason: String,
    pub action: String,
}

#[derive(Debug)]
pub struct Classification {
    pub family: String,
    pub family_label: String,
    pub subtype: Option<String>,
    pub region: Option<String>,
}

impl Catalog {
    pub fn load(path: &Path) -> Result<Self, Box<dyn Error>> {
        let raw = std::fs::read_to_string(path)
            .map_err(|e| format!("cannot read catalog {}: {e}", path.display()))?;
        Ok(serde_json::from_str(&raw)?)
    }

    pub fn lookup(&self, code: &str) -> Option<&CodeEntry> {
        self.codes.get(code)
    }

    /// Resolve the governing procedure family, subtype, and region.
    pub fn classify(&self, codes: &[String]) -> Result<Classification, String> {
        let entries = codes
            .iter()
            .map(|c| {
                self.lookup(c)
                    .ok_or_else(|| format!("code {c} is not in the catalog; refusing to classify"))
            })
            .collect::<Result<Vec<_>, _>>()?;

        let family = self
            .family_precedence
            .iter()
            .find(|f| entries.iter().any(|e| &e.family == *f))
            .ok_or("request contains no primary procedure code; adjunct codes alone cannot be classified")?;

        let members: Vec<&&CodeEntry> = entries.iter().filter(|e| &e.family == family).collect();

        let subtype = match family.as_str() {
            "facet_intervention" => Some(
                if members.iter().any(|e| e.subtype.as_deref() == Some("rfa")) {
                    "rfa"
                } else {
                    "diagnostic_block"
                },
            ),
            "spinal_cord_stimulator" => {
                Some(if members.iter().any(|e| e.category == "generator") {
                    "permanent"
                } else {
                    "trial"
                })
            }
            _ => None,
        }
        .map(str::to_owned);

        Ok(Classification {
            family_label: self
                .family_labels
                .get(family)
                .cloned()
                .unwrap_or_else(|| family.clone()),
            family: family.clone(),
            subtype,
            region: members.iter().find_map(|e| e.region.clone()),
        })
    }
}
