//! Case enrichment: classification, derived facts, and pre-send gates.
//!
//! Templates render; they never decide. Every value a template branches on
//! that requires computation (code classification, date arithmetic, threshold
//! comparison, exhibit integrity) is produced here, once. The letter and the
//! halt memo therefore can never disagree about the state of a case.
//!
//! Gate semantics are fail-closed: any `void` or `open_gap` item sets
//! `gate.halt`, and the root template renders an internal memo instead of a
//! payer-facing letter.

use crate::catalog::Catalog;
use serde_json::{Map, Value, json};

/// Letter kinds. Each selects `templates/kinds/<kind>.md.j2`.
const KINDS: &[&str] = &["initial_request", "denial_response"];
/// Statuses that describe a prior determination; meaningless before one exists.
const RESPONSE_ONLY_STATUSES: &[&str] = &["GAP_CLOSED", "DISPUTED"];
const PROGRAMS: &[&str] = &[
    "medicare_ffs_opd",
    "medicare_advantage",
    "commercial",
    "medicaid",
];
const PATTERNS: &[&str] = &[
    "overlooked",
    "newly_supplied",
    "not_applicable",
    "misapplied",
    "clinical_exception",
];
const STATUSES: &[&str] = &[
    "MET",
    "GAP_CLOSED",
    "NOT_APPLICABLE",
    "DISPUTED",
    "VOID",
    "GAP",
];

type DatedText<'a> = (i64, &'a str);

#[derive(Default)]
struct Gate {
    items: Vec<Value>,
}

impl Gate {
    fn push(&mut self, kind: &str, source: &str, reference: &str, detail: String, action: &str) {
        self.items.push(json!({
            "kind": kind, "source": source, "ref": reference, "detail": detail, "action": action,
        }));
    }
    fn void(&mut self, source: &str, reference: &str, detail: String, action: &str) {
        self.push("void", source, reference, detail, action);
    }
    fn gap(&mut self, source: &str, reference: &str, detail: String, action: &str) {
        self.push("open_gap", source, reference, detail, action);
    }
    fn into_value(self) -> Value {
        let count = |k: &str| self.items.iter().filter(|i| i["kind"] == k).count();
        json!({
            "halt": !self.items.is_empty(),
            "void_count": count("void"),
            "gap_count": count("open_gap"),
            "items": self.items,
        })
    }
}

pub fn enrich(case: &mut Value, catalog: &Catalog) -> Result<(), String> {
    let kind = text(case, "/letter/kind")
        .ok_or("letter.kind is required: `initial_request` or `denial_response`")?
        .to_owned();
    if !KINDS.contains(&kind.as_str()) {
        return Err(format!(
            "unsupported letter.kind `{kind}`; expected `initial_request` or `denial_response`"
        ));
    }
    let program = text(case, "/payer/program")
        .ok_or("payer.program is required")?
        .to_owned();
    if !PROGRAMS.contains(&program.as_str()) {
        return Err(format!("unsupported payer.program `{program}`"));
    }

    let codes = classify_services(case, catalog)?;
    let class = catalog.classify(&codes)?;
    {
        let procedure = obj_mut(case, "/procedure")?;
        let level_count = procedure
            .get("levels")
            .and_then(Value::as_array)
            .map_or(0, Vec::len);
        procedure.insert("family".into(), json!(class.family));
        procedure.insert("family_label".into(), json!(class.family_label));
        procedure.insert("subtype".into(), json!(class.subtype));
        procedure.insert("region".into(), json!(class.region));
        procedure.insert("level_count".into(), json!(level_count));
    }
    default_signing_provider(case)?;
    add_inline_forms(case);

    let mut gate = Gate::default();
    let mut derived = Map::new();
    let mut warnings: Vec<String> = Vec::new();
    let dos = text(case, "/procedure/anticipated_dos").and_then(parse_date);

    check_criteria(case, &kind, &mut gate, &mut derived)?;
    check_code_rules(&codes, &program, catalog, &mut gate);
    check_level_limit(case, &mut gate);

    let bypass = !arr(case, "/clinical/red_flags").is_empty()
        && flag(case, "/policy/red_flag_bypass_allowed");
    derived.insert("red_flag_bypass".into(), json!(bypass));

    check_conservative_care(case, bypass, &mut gate, &mut derived);
    check_imaging(case, dos, &mut gate, &mut derived);
    check_risk_factors(case, dos, &mut gate);
    match class.family.as_str() {
        "facet_intervention" => {
            check_facet(case, class.subtype.as_deref(), &mut gate, &mut derived)
        }
        "spinal_cord_stimulator" => check_scs(case, class.subtype.as_deref(), &mut gate),
        _ => {}
    }
    check_denial_reasons(case, &kind, &mut gate)?;
    check_exhibit_refs(case, &mut gate);
    filter_unverified_references(case, &mut warnings)?;

    derived.insert("warnings".into(), json!(warnings));
    let root = case.as_object_mut().ok_or("case must be a JSON object")?;
    root.insert("derived".into(), Value::Object(derived));
    root.insert("gate".into(), gate.into_value());
    Ok(())
}

// ── Classification ─────────────────────────────────────────────────────────

fn classify_services(case: &mut Value, catalog: &Catalog) -> Result<Vec<String>, String> {
    let services = case
        .pointer_mut("/procedure/services")
        .and_then(Value::as_array_mut)
        .ok_or("procedure.services is required")?;
    let mut codes = Vec::with_capacity(services.len());
    for svc in services.iter_mut() {
        let code = svc
            .get("code")
            .and_then(Value::as_str)
            .ok_or("service is missing `code`")?
            .to_owned();
        let entry = catalog
            .lookup(&code)
            .ok_or_else(|| format!("code {code} is not in the catalog; refusing to classify"))?;
        let obj = svc.as_object_mut().ok_or("service must be an object")?;
        obj.insert("category".into(), json!(entry.category));
        obj.insert("is_addon".into(), json!(entry.category != "primary"));
        obj.entry("description")
            .or_insert_with(|| json!(entry.description));
        obj.entry("modifiers").or_insert_with(|| json!([]));
        codes.push(code);
    }
    Ok(codes)
}

fn default_signing_provider(case: &mut Value) -> Result<(), String> {
    let providers = obj_mut(case, "/providers")?;
    if !providers.contains_key("signing") {
        let requesting = providers
            .get("requesting")
            .cloned()
            .ok_or("providers.requesting is required")?;
        providers.insert("signing".into(), requesting);
    }
    Ok(())
}

/// Mid-sentence forms: "Bilateral lumbar RFA" → "bilateral lumbar RFA", but "L4-L5 fusion" is unchanged.
fn add_inline_forms(case: &mut Value) {
    if let Some(desc) = text(case, "/procedure/description").map(inline_case)
        && let Some(p) = case
            .pointer_mut("/procedure")
            .and_then(Value::as_object_mut)
    {
        p.insert("description_inline".into(), json!(desc));
    }
    if let Some(flags) = case
        .pointer_mut("/clinical/red_flags")
        .and_then(Value::as_array_mut)
    {
        for f in flags.iter_mut() {
            if let Some(inline) = f.get("flag").and_then(Value::as_str).map(inline_case)
                && let Some(obj) = f.as_object_mut()
            {
                obj.insert("flag_inline".into(), json!(inline));
            }
        }
    }
}

fn inline_case(s: &str) -> String {
    let mut chars = s.chars();
    match (chars.next(), chars.next()) {
        (Some(first), Some(second))
            if first.is_ascii_uppercase() && second.is_ascii_lowercase() =>
        {
            let mut out = first.to_ascii_lowercase().to_string();
            out.push_str(&s[1..]);
            out
        }
        _ => s.to_owned(),
    }
}

// ── Gates ──────────────────────────────────────────────────────────────────

fn check_criteria(
    case: &Value,
    kind: &str,
    gate: &mut Gate,
    derived: &mut Map<String, Value>,
) -> Result<(), String> {
    let mut gap_closed = Vec::new();
    for c in arr(case, "/criteria") {
        let id = text(c, "/id").unwrap_or("?");
        let status = text(c, "/status").ok_or_else(|| format!("criterion {id} has no status"))?;
        if !STATUSES.contains(&status) {
            return Err(format!("criterion {id} has unknown status `{status}`"));
        }
        if kind == "initial_request" && RESPONSE_ONLY_STATUSES.contains(&status) {
            return Err(format!(
                "criterion {id} uses status `{status}`, which describes a prior determination; \
                 initial requests use MET, NOT_APPLICABLE, GAP, or VOID"
            ));
        }
        let criterion = text(c, "/text").unwrap_or_default();
        match status {
            "VOID" => gate.void(
                "criterion", id,
                format!("{criterion} — {}", text(c, "/evidence").unwrap_or("criterion cannot be satisfied")),
                "Revise the request, consider a clinical exception request, or begin patient financial counseling.",
            ),
            "GAP" => gate.gap(
                "criterion", id,
                format!("{criterion} — no supporting documentation on file."),
                "Obtain documentation, update the case record, and regenerate.",
            ),
            "GAP_CLOSED" => gap_closed.push(id.to_owned()),
            _ => {}
        }
    }
    derived.insert("gap_closed_ids".into(), json!(gap_closed));
    Ok(())
}

fn check_code_rules(codes: &[String], program: &str, catalog: &Catalog, gate: &mut Gate) {
    for rule in catalog
        .void_rules
        .iter()
        .filter(|r| r.programs.iter().any(|p| p == program))
    {
        for code in codes.iter().filter(|c| rule.codes.contains(c)) {
            gate.void("code_rule", code, rule.reason.clone(), &rule.action);
        }
    }
}

fn check_level_limit(case: &Value, gate: &mut Gate) {
    let levels = arr(case, "/procedure/levels").len() as f64;
    if let Some(max) = num(case, "/policy/max_levels")
        && levels > max
    {
        gate.void(
            "policy_threshold",
            "max_levels",
            format!("{levels} levels requested; the policy permits at most {max}."),
            "Reduce the number of levels or request a clinical exception.",
        );
    }
}

fn check_conservative_care(
    case: &Value,
    bypass: bool,
    gate: &mut Gate,
    derived: &mut Map<String, Value>,
) {
    let entries = arr(case, "/clinical/conservative_care");
    let min_weeks = num(case, "/policy/min_conservative_weeks");

    // (days since epoch, original ISO text) for the earliest start and latest end.
    let mut start: Option<DatedText> = None;
    let mut end: Option<DatedText> = None;
    let mut categories: Vec<&str> = Vec::new();
    for e in entries {
        if let Some(cat) = text(e, "/category")
            && !categories.contains(&cat)
        {
            categories.push(cat);
        }
        if flag(e, "/contraindicated") {
            continue;
        }
        if let Some(s) = text(e, "/start")
            && let Some(d) = parse_date(s)
            && start.is_none_or(|(cur, _)| d < cur)
        {
            start = Some((d, s));
        }
        if let Some(s) = text(e, "/end")
            && let Some(d) = parse_date(s)
            && end.is_none_or(|(cur, _)| d > cur)
        {
            end = Some((d, s));
        }
    }

    let span_weeks = match (start, end) {
        (Some((s, s_txt)), Some((e, e_txt))) => {
            derived.insert("conservative_start".into(), json!(s_txt));
            derived.insert("conservative_end".into(), json!(e_txt));
            (e - s) / 7
        }
        _ => 0,
    };
    derived.insert("conservative_span_weeks".into(), json!(span_weeks));
    derived.insert(
        "modalities_completed".into(),
        json!(
            categories
                .iter()
                .map(|c| modality_label(c))
                .collect::<Vec<_>>()
        ),
    );

    if bypass {
        return;
    }
    if let Some(min) = min_weeks
        && (span_weeks as f64) < min
    {
        gate.gap(
            "policy_threshold", "min_conservative_weeks",
            format!("Conservative care spans {span_weeks} weeks; the policy requires {min}. No red-flag bypass applies."),
            "Document additional conservative care or red-flag findings, then regenerate.",
        );
    }
    for required in arr(case, "/policy/required_modalities")
        .iter()
        .filter_map(Value::as_str)
    {
        if !categories.contains(&required) {
            gate.gap(
                "policy_threshold",
                "required_modalities",
                format!(
                    "Required conservative modality not documented: {}.",
                    modality_label(required)
                ),
                "Document the modality or its contraindication, then regenerate.",
            );
        }
    }
}

fn check_imaging(
    case: &Value,
    dos: Option<i64>,
    gate: &mut Gate,
    derived: &mut Map<String, Value>,
) {
    let latest = arr(case, "/clinical/imaging")
        .iter()
        .filter(|i| flag(i, "/advanced"))
        .filter_map(|i| text(i, "/date").and_then(parse_date).map(|d| (d, i)))
        .max_by_key(|(d, _)| *d);

    let Some(window) = num(case, "/policy/max_imaging_age_months") else {
        return;
    };
    match (latest, dos) {
        (None, _) => gate.gap(
            "policy_threshold",
            "max_imaging_age_months",
            "No advanced imaging (MRI/CT/myelography) is on file.".into(),
            "Obtain advanced imaging, then regenerate.",
        ),
        (Some(_), None) => gate.gap(
            "case_record",
            "procedure.anticipated_dos",
            "Anticipated date of service is missing; imaging recency cannot be verified.".into(),
            "Record the anticipated date of service, then regenerate.",
        ),
        (Some((date, study)), Some(dos)) => {
            let age = months_between(date, dos);
            derived.insert(
                "latest_advanced_imaging".into(),
                json!({
                    "study": study["study"], "date": study["date"], "age_months": age,
                }),
            );
            if (age as f64) > window {
                gate.gap(
                    "policy_threshold", "max_imaging_age_months",
                    format!("Most recent advanced imaging is {age} months old; the policy window is {window} months."),
                    "Obtain updated imaging, then regenerate.",
                );
            }
        }
    }
}

fn check_risk_factors(case: &Value, dos: Option<i64>, gate: &mut Gate) {
    for (value_ptr, limit_ptr, label) in [
        ("/clinical/risk_factors/bmi/value", "/policy/max_bmi", "BMI"),
        (
            "/clinical/risk_factors/hba1c/value",
            "/policy/max_hba1c",
            "HbA1c",
        ),
    ] {
        if let (Some(v), Some(max)) = (num(case, value_ptr), num(case, limit_ptr))
            && v > max
        {
            gate.gap(
                "policy_threshold",
                label,
                format!("{label} {v} exceeds the policy threshold of {max}."),
                "Document optimization or request a clinical exception, then regenerate.",
            );
        }
    }

    let Some(status) = text(case, "/clinical/risk_factors/nicotine/status") else {
        return;
    };
    let required_weeks = num(case, "/policy/nicotine_free_weeks");
    if status == "current" && required_weeks.is_some() {
        gate.gap(
            "policy_threshold",
            "nicotine",
            "Current nicotine use is documented; the policy requires abstinence.".into(),
            "Document cessation and verification, then regenerate.",
        );
        return;
    }
    if status == "former"
        && let Some(req) = required_weeks
        && let (Some(quit), Some(dos)) = (
            text(case, "/clinical/risk_factors/nicotine/quit_date").and_then(parse_date),
            dos,
        )
        && (((dos - quit) / 7) as f64) < req
    {
        gate.gap(
            "policy_threshold",
            "nicotine",
            format!("Nicotine-free interval before the date of service is under {req} weeks."),
            "Defer the date of service or document an exception, then regenerate.",
        );
    }
    if status != "never"
        && flag(case, "/policy/nicotine_verification_required")
        && text(case, "/clinical/risk_factors/nicotine/verification").is_none()
    {
        gate.gap(
            "policy_threshold", "nicotine",
            "The policy requires verified nicotine abstinence (for example, cotinine testing); none is on file.".into(),
            "Obtain verification, then regenerate.",
        );
    }
}

fn check_facet(
    case: &Value,
    subtype: Option<&str>,
    gate: &mut Gate,
    derived: &mut Map<String, Value>,
) {
    if subtype == Some("rfa") {
        let min_relief = num(case, "/policy/min_block_relief_pct").unwrap_or(80.0);
        let required = num(case, "/policy/required_blocks").unwrap_or(2.0);
        let qualifying = arr(case, "/clinical/diagnostic_blocks")
            .iter()
            .filter(|b| num(b, "/relief_pct").is_some_and(|r| r >= min_relief))
            .count();
        derived.insert("qualifying_blocks".into(), json!(qualifying));
        if (qualifying as f64) < required {
            gate.gap(
                "policy_threshold", "diagnostic_blocks",
                format!("{qualifying} diagnostic block(s) with at least {min_relief}% relief are documented; {required} are required."),
                "Document the qualifying diagnostic blocks, then regenerate.",
            );
        }
    }

    if flag(case, "/procedure/is_repeat") {
        let latest = arr(case, "/clinical/prior_rfa")
            .iter()
            .filter_map(|p| text(p, "/date").and_then(parse_date).map(|d| (d, p)))
            .max_by_key(|(d, _)| *d);
        let min_pct = num(case, "/policy/min_repeat_relief_pct").unwrap_or(50.0);
        let min_months = num(case, "/policy/min_repeat_relief_months").unwrap_or(6.0);
        let meets = latest.is_some_and(|(_, p)| {
            num(p, "/relief_pct").is_some_and(|r| r >= min_pct)
                && num(p, "/relief_months").is_some_and(|m| m >= min_months)
        });
        if !meets {
            gate.gap(
                "policy_threshold", "repeat_rfa",
                format!("Repeat ablation requires at least {min_pct}% relief lasting {min_months} months from the prior ablation."),
                "Document the prior ablation response, then regenerate.",
            );
        }
    }

    if let Some(max) = num(case, "/policy/max_sessions_12mo") {
        let prior = num(case, "/procedure/sessions_rolling_12mo").unwrap_or(0.0);
        if prior + 1.0 > max {
            gate.void(
                "policy_threshold",
                "max_sessions_12mo",
                format!(
                    "This would be session {} in the rolling 12 months; the policy permits {max}.",
                    prior + 1.0
                ),
                "Reschedule outside the frequency window or evaluate an alternative service.",
            );
        }
    }
}

fn check_scs(case: &Value, subtype: Option<&str>, gate: &mut Gate) {
    if !flag(case, "/clinical/psych_eval/cleared") {
        gate.gap(
            "policy_threshold",
            "psych_eval",
            "No psychological evaluation clearing the patient for neurostimulation is on file."
                .into(),
            "Obtain the evaluation, then regenerate.",
        );
    }
    if subtype == Some("permanent") {
        let min = num(case, "/policy/min_trial_relief_pct").unwrap_or(50.0);
        let relief = num(case, "/clinical/scs_trial/relief_pct");
        if !relief.is_some_and(|r| r >= min) {
            gate.gap(
                "policy_threshold", "scs_trial",
                format!("Permanent implantation requires a documented trial with at least {min}% relief."),
                "Document the trial outcome, then regenerate.",
            );
        }
    }
}

fn check_denial_reasons(case: &Value, kind: &str, gate: &mut Gate) -> Result<(), String> {
    let reasons = arr(case, "/denial_reasons");
    if kind == "initial_request" {
        return if reasons.is_empty() {
            Ok(())
        } else {
            Err("denial_reasons must be empty for an initial_request; use `denial_response` to answer a denial".into())
        };
    }
    if reasons.is_empty() {
        return Err("denial_reasons must contain at least one reason".into());
    }
    for (i, r) in reasons.iter().enumerate() {
        let n = i + 1;
        let pattern =
            text(r, "/pattern").ok_or_else(|| format!("denial reason {n} has no pattern"))?;
        if !PATTERNS.contains(&pattern) {
            return Err(format!("denial reason {n} has unknown pattern `{pattern}`"));
        }
        let reference = format!("denial_reason_{n}");
        if matches!(pattern, "overlooked" | "newly_supplied") && text(r, "/exhibit").is_none() {
            gate.gap(
                "denial_reason",
                &reference,
                format!("Pattern `{pattern}` requires enclosed evidence, but no exhibit is cited."),
                "Attach and cite the supporting exhibit, then regenerate.",
            );
        }
        if pattern == "misapplied" && text(r, "/policy_quote").is_none() {
            gate.gap(
                "denial_reason",
                &reference,
                "Pattern `misapplied` requires the governing policy language, quoted verbatim."
                    .into(),
                "Add the verbatim policy quote, then regenerate.",
            );
        }
    }
    Ok(())
}

/// Every `exhibit` or `*_exhibit` value anywhere in the case must resolve to an enclosure.
fn check_exhibit_refs(case: &Value, gate: &mut Gate) {
    let labels: Vec<&str> = arr(case, "/exhibits")
        .iter()
        .filter_map(|e| text(e, "/label"))
        .collect();
    let mut refs = Vec::new();
    collect_exhibit_refs(case, &mut refs);
    refs.sort();
    refs.dedup();
    for r in refs.iter().filter(|r| !labels.contains(&r.as_str())) {
        gate.gap(
            "exhibit_integrity",
            r,
            format!("Exhibit {r} is cited but not listed in the enclosures."),
            "Add the document to the enclosures or correct the citation, then regenerate.",
        );
    }
}

fn collect_exhibit_refs(v: &Value, out: &mut Vec<String>) {
    match v {
        Value::Object(map) => {
            for (k, child) in map {
                if (k == "exhibit" || k.ends_with("_exhibit"))
                    && let Some(s) = child.as_str()
                    && let Some(label) = s
                        .split([',', ' ', ';'])
                        .next()
                        .filter(|l| !l.is_empty() && *l != "—")
                {
                    out.push(label.to_owned());
                }
                collect_exhibit_refs(child, out);
            }
        }
        Value::Array(items) => items.iter().for_each(|i| collect_exhibit_refs(i, out)),
        _ => {}
    }
}

/// Unverified literature is removed from the letter and surfaced as a review warning.
fn filter_unverified_references(
    case: &mut Value,
    warnings: &mut Vec<String>,
) -> Result<(), String> {
    let Some(refs) = case.get_mut("references").and_then(Value::as_array_mut) else {
        return Ok(());
    };
    refs.retain(|r| {
        let verified = r.get("verified").and_then(Value::as_bool).unwrap_or(false);
        if !verified {
            let cite = r
                .get("citation")
                .and_then(Value::as_str)
                .unwrap_or("(untitled)");
            warnings.push(format!(
                "Unverified reference removed from the letter: {cite}"
            ));
        }
        verified
    });
    Ok(())
}

// ── Helpers ────────────────────────────────────────────────────────────────

fn modality_label(category: &str) -> &str {
    match category {
        "physical_therapy" => "physical therapy",
        "medication" => "medication management",
        "injection" => "injection therapy",
        "home_exercise" => "a home exercise program",
        "activity_modification" => "activity modification",
        "bracing" => "bracing",
        "chiropractic" => "chiropractic care",
        "weight_management" => "weight management",
        "behavioral" => "behavioral therapy",
        "assistive_device" => "an assistive device",
        other => other,
    }
}

fn text<'a>(v: &'a Value, ptr: &str) -> Option<&'a str> {
    v.pointer(ptr)?.as_str()
}

fn num(v: &Value, ptr: &str) -> Option<f64> {
    v.pointer(ptr)?.as_f64()
}

fn flag(v: &Value, ptr: &str) -> bool {
    v.pointer(ptr).and_then(Value::as_bool).unwrap_or(false)
}

fn arr<'a>(v: &'a Value, ptr: &str) -> &'a [Value] {
    v.pointer(ptr)
        .and_then(Value::as_array)
        .map_or(&[], Vec::as_slice)
}

fn obj_mut<'a>(v: &'a mut Value, ptr: &str) -> Result<&'a mut Map<String, Value>, String> {
    v.pointer_mut(ptr)
        .and_then(Value::as_object_mut)
        .ok_or_else(|| format!("`{ptr}` must be an object"))
}

/// Parse an ISO `YYYY-MM-DD` prefix into days since the Unix epoch.
pub fn parse_date(s: &str) -> Option<i64> {
    let mut parts = s.get(..10)?.split('-');
    let y: i64 = parts.next()?.parse().ok()?;
    let m: i64 = parts.next()?.parse().ok()?;
    let d: i64 = parts.next()?.parse().ok()?;
    if !(1..=12).contains(&m) || !(1..=31).contains(&d) {
        return None;
    }
    // Days-from-civil (proleptic Gregorian).
    let y = if m <= 2 { y - 1 } else { y };
    let era = (if y >= 0 { y } else { y - 399 }) / 400;
    let yoe = y - era * 400;
    let mp = (m + 9) % 12;
    let doy = (153 * mp + 2) / 5 + d - 1;
    let doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    Some(era * 146_097 + doe - 719_468)
}

fn months_between(from: i64, to: i64) -> i64 {
    ((to - from) as f64 / 30.44).floor() as i64
}

#[cfg(test)]
mod tests {
    use super::{inline_case, parse_date};

    #[test]
    fn inline_case_preserves_acronyms() {
        assert_eq!(inline_case("Bilateral lumbar RFA"), "bilateral lumbar RFA");
        assert_eq!(inline_case("L4-L5 decompression"), "L4-L5 decompression");
        assert_eq!(inline_case("MRI-guided"), "MRI-guided");
    }

    #[test]
    fn epoch_and_leap_day() {
        assert_eq!(parse_date("1970-01-01"), Some(0));
        assert_eq!(
            parse_date("2024-03-01").unwrap() - parse_date("2024-02-28").unwrap(),
            2
        );
        assert_eq!(parse_date("2026-13-01"), None);
    }
}
